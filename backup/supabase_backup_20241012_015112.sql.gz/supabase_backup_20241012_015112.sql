--
-- PostgreSQL database dump
--

-- Dumped from database version 15.6
-- Dumped by pg_dump version 17.0 (Ubuntu 17.0-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- Name: pgsodium; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA pgsodium;


ALTER SCHEMA pgsodium OWNER TO supabase_admin;

--
-- Name: pgsodium; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgsodium WITH SCHEMA pgsodium;


--
-- Name: EXTENSION pgsodium; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgsodium IS 'Pgsodium is a modern cryptography library for Postgres.';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_graphql WITH SCHEMA graphql;


--
-- Name: EXTENSION pg_graphql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_graphql IS 'pg_graphql: GraphQL support';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: pgjwt; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgjwt WITH SCHEMA extensions;


--
-- Name: EXTENSION pgjwt; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgjwt IS 'JSON Web Token API for Postgresql';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_admin;

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_admin;

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_admin;

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_admin;

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_admin;

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO postgres;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
    ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

    ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
    ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

    REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
    REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

    GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO postgres;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: postgres
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RAISE WARNING 'PgBouncer auth request: %', p_usename;

    RETURN QUERY
    SELECT usename::TEXT, passwd::TEXT FROM pg_catalog.pg_shadow
    WHERE usename = p_usename;
END;
$$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO postgres;

--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or action = 'DELETE'
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_admin;

--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_admin;

--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_admin;

--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_admin;

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_admin;

--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_admin;

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
_filename text;
BEGIN
	select string_to_array(name, '/') into _parts;
	select _parts[array_length(_parts,1)] into _filename;
	-- @todo return the last part instead of 2
	return reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[1:array_length(_parts,1)-1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::int) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO supabase_storage_admin;

--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text) OWNER TO supabase_storage_admin;

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
  v_order_by text;
  v_sort_order text;
begin
  case
    when sortcolumn = 'name' then
      v_order_by = 'name';
    when sortcolumn = 'updated_at' then
      v_order_by = 'updated_at';
    when sortcolumn = 'created_at' then
      v_order_by = 'created_at';
    when sortcolumn = 'last_accessed_at' then
      v_order_by = 'last_accessed_at';
    else
      v_order_by = 'name';
  end case;

  case
    when sortorder = 'asc' then
      v_sort_order = 'asc';
    when sortorder = 'desc' then
      v_sort_order = 'desc';
    else
      v_sort_order = 'asc';
  end case;

  v_order_by = v_order_by || ' ' || v_sort_order;

  return query execute
    'with folders as (
       select path_tokens[$1] as folder
       from storage.objects
         where objects.name ilike $2 || $3 || ''%''
           and bucket_id = $4
           and array_length(objects.path_tokens, 1) <> $1
       group by folder
       order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

--
-- Name: secrets_encrypt_secret_secret(); Type: FUNCTION; Schema: vault; Owner: supabase_admin
--

CREATE FUNCTION vault.secrets_encrypt_secret_secret() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		BEGIN
		        new.secret = CASE WHEN new.secret IS NULL THEN NULL ELSE
			CASE WHEN new.key_id IS NULL THEN NULL ELSE pg_catalog.encode(
			  pgsodium.crypto_aead_det_encrypt(
				pg_catalog.convert_to(new.secret, 'utf8'),
				pg_catalog.convert_to((new.id::text || new.description::text || new.created_at::text || new.updated_at::text)::text, 'utf8'),
				new.key_id::uuid,
				new.nonce
			  ),
				'base64') END END;
		RETURN new;
		END;
		$$;


ALTER FUNCTION vault.secrets_encrypt_secret_secret() OWNER TO supabase_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: artikels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.artikels (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    thumbnail text NOT NULL,
    author_id text NOT NULL,
    category_id text NOT NULL,
    slug text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text
);


ALTER TABLE public.artikels OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    type text DEFAULT 'merchant'::text NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: contents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contents (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    image text NOT NULL,
    link_ig text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contents OWNER TO postgres;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departments (
    id text NOT NULL,
    name text NOT NULL,
    short_name text NOT NULL,
    description text,
    logo text,
    year integer NOT NULL,
    department_type text DEFAULT 'bph'::text NOT NULL
);


ALTER TABLE public.departments OWNER TO postgres;

--
-- Name: divisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.divisions (
    id text NOT NULL,
    name text NOT NULL,
    department_id text NOT NULL
);


ALTER TABLE public.divisions OWNER TO postgres;

--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    thumbnail text NOT NULL,
    link_ig text NOT NULL,
    date_start timestamp(3) without time zone NOT NULL,
    date_end timestamp(3) without time zone NOT NULL,
    author_id text NOT NULL,
    category_id text
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: kepengurusan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kepengurusan (
    year integer NOT NULL
);


ALTER TABLE public.kepengurusan OWNER TO postgres;

--
-- Name: members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.members (
    id text NOT NULL,
    name text NOT NULL,
    department_id text NOT NULL,
    "position" text NOT NULL,
    link_ig text,
    link_linkedin text,
    motto text,
    photo text,
    division_id text,
    year integer NOT NULL
);


ALTER TABLE public.members OWNER TO postgres;

--
-- Name: merchants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.merchants (
    id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    thumbnail text NOT NULL,
    category_id text NOT NULL,
    price integer NOT NULL,
    link_whatsapp text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.merchants OWNER TO postgres;

--
-- Name: portofolios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.portofolios (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    thumbnail text,
    category_id text NOT NULL,
    link_project text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.portofolios OWNER TO postgres;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refresh_tokens (
    token text NOT NULL,
    user_id text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    role text DEFAULT 'non-student'::text NOT NULL,
    department_id text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    id bigint NOT NULL,
    topic text NOT NULL,
    extension text NOT NULL,
    inserted_at timestamp(0) without time zone NOT NULL,
    updated_at timestamp(0) without time zone NOT NULL
);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE SEQUENCE realtime.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE realtime.messages_id_seq OWNER TO supabase_realtime_admin;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER SEQUENCE realtime.messages_id_seq OWNED BY realtime.messages.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


ALTER TABLE realtime.subscription OWNER TO supabase_admin;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- Name: decrypted_secrets; Type: VIEW; Schema: vault; Owner: supabase_admin
--

CREATE VIEW vault.decrypted_secrets AS
 SELECT secrets.id,
    secrets.name,
    secrets.description,
    secrets.secret,
        CASE
            WHEN (secrets.secret IS NULL) THEN NULL::text
            ELSE
            CASE
                WHEN (secrets.key_id IS NULL) THEN NULL::text
                ELSE convert_from(pgsodium.crypto_aead_det_decrypt(decode(secrets.secret, 'base64'::text), convert_to(((((secrets.id)::text || secrets.description) || (secrets.created_at)::text) || (secrets.updated_at)::text), 'utf8'::name), secrets.key_id, secrets.nonce), 'utf8'::name)
            END
        END AS decrypted_secret,
    secrets.key_id,
    secrets.nonce,
    secrets.created_at,
    secrets.updated_at
   FROM vault.secrets;


ALTER VIEW vault.decrypted_secrets OWNER TO supabase_admin;

--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages ALTER COLUMN id SET DEFAULT nextval('realtime.messages_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag) FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- Data for Name: key; Type: TABLE DATA; Schema: pgsodium; Owner: supabase_admin
--

COPY pgsodium.key (id, status, created, expires, key_type, key_id, key_context, name, associated_data, raw_key, raw_key_nonce, parent_key, comment, user_data) FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
eb8cb5b7-b2d4-4f3f-9bd6-8d2339e621ed	a74aad491b95c55819e279cd08cedfb2cff36bf475a28145b67f2e5966a93a63	2024-08-18 09:39:57.122403+00	20240818093956_database_v1	\N	\N	2024-08-18 09:39:56.632892+00	1
b8e29f14-f0e3-438d-b818-ac02360331d1	608a268eb5bb64e744890f15863bd746a61a7b7b4c8be7446862b13754688056	2024-08-27 15:23:56.308703+00	20240827152355_indexes_database	\N	\N	2024-08-27 15:23:56.074514+00	1
e89f3827-c4bc-47e3-b5f9-937ff40e8aae	c906d3db8468b72fdd281000decfa6c834ccfc80c44aef5b6d9a8b22ff4dfdc3	2024-08-31 14:29:44.007245+00	20240831142943_add_description_artikel	\N	\N	2024-08-31 14:29:43.870971+00	1
\.


--
-- Data for Name: artikels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.artikels (id, title, content, thumbnail, author_id, category_id, slug, "createdAt", "updatedAt", description) FROM stdin;
8bf21744-635e-4652-9548-fcf8f0bd03be	Data Science: Yuk, Kenalan sama Si Keren Ini!	Yo, apa kabar sobat Data! Udah pernah denger istilah "Data Science" belum? Kalo belum, tenang aja, gue bakal jelasin ke lo semua tentang si keren ini. Siap-siap ya, karena kita bakal nyemplung ke dunia yang asyik banget!\n\n# Apaan sih Data Science Itu?\n\nGampangnya, Data Science tuh kayak jadi detektif di dunia digital. Lo bakal ngulik-ngulik data yang bejibun banyaknya, terus nyari petunjuk dan pola yang tersembunyi di dalemnya. Keren kan?\n\nData Science itu campuran dari beberapa ilmu:\n\n- Statistik (buat ngitung-ngitung)\n- Ilmu Komputer (biar bisa ngoding)Nah, gabungan dari semua itu bikin Data Science jadi "senjata pamungkas" buat mecahin masalah di dunia nyata.\n# Kenapa Data Science Itu Penting Banget?\n\nCoba deh bayangin:\n\n- Netflix bisa ngasih rekomendasi film yang cocok buat lo\n- Gojek bisa nentuin harga yang pas dan driver yang dekat dengan lo.\n- Bank bisa deteksi transaksi mencurigakanNah, itu semua berkat Data Science, bro!\n# Skill Apa Aja yang Harus Dikuasain?\n\nKalo lo mau jadi Data Scientist, ini nih beberapa skill yang wajib lo kuasain:\n\n- Programming: Python atau R tuh wajib hukumnya. Ibarat kata, ini tuh kayak punya HP canggih di kantong lo.\n- Statistik: Jago statistik itu kayak punya kacamata ajaib buat liat pola di data.\n- Machine Learning: Ini tuh kayak ngajarin komputer buat mikir sendiri. Keren kan?\n- Data Visualization: Karena kadang, gambar tuh lebih ngena daripada 1000 kata.\n- Domain Expertise: Lo harus ngerti bidang yang lo teliti. Masa mau analisis data sepak bola tapi gak tau offside?\n# Gimana Cara Mulainya?\n\n- Belajar Python atau R: Mulai dari yang basic aja. Ada banyak tutorial gratis di YouTube atau Coursera.\n- Latihan pake dataset: Cari dataset di , terus coba-coba analisis.\n- Ikut komunitas: Join grup Data Science di Facebook atau Reddit. Jangan malu buat nanya!\n- Bikin projek: Cari masalah di sekitar lo, terus coba pecahin pake Data Science.\n- Keep Learning: Data Science tuh berkembang terus. Jadi, jangan pernah berhenti belajar ya!\n# Kesimpulan\n\nNah, gimana sob? Udah mulai ngerti kan apa itu Data Science? Inget ya, ini cuma pengantar doang. Masih banyak lagi yang bisa lo pelajari.\n\nData Science itu kayak main game RPG. Awalnya mungkin lo bingung, tapi makin lama makin seru. Jadi, jangan nyerah di tengah jalan ya!\n\nYuk, mulai petualangan lo di dunia Data Science. Siapa tau, beberapa tahun lagi lo bisa jadi Data Scientist kece yang bikin impact besar di dunia. Semangat belajar, Bro dan Sis! \n\nSALAM DATA SALAM ADYATAMA\n	https://res.cloudinary.com/diqabuwwk/image/upload/v1725037305/WISATA/file_ys8bgq.jpg	116729146132809119225	c50cca72-d4e3-4d2f-9055-92e9ddac3dc6	data-science-yuk-kenalan-sama-si-keren-ini	2024-08-30 17:01:46.998	2024-08-31 15:37:55.322	Apa sih Data Science? Artikel ini mengajak Anda masuk ke dunia seru Data Science, di mana Anda bisa menjadi detektif digital yang mengulik data dan menemukan pola tersembunyi. Mulai dari pengertian dasar hingga skill yang dibutuhkan untuk menjadi Data Scientist, semuanya dikupas dengan gaya santai dan asyik
b88a1a3d-63f8-45dd-9c53-fdbe0a05d0fe	Menguasai Perintah Dasar Git dan GitHub: Panduan Praktis untuk Pemula	Sebagai seorang pengembang perangkat lunak, Anda pasti pernah mendengar tentang Git dan GitHub. Dua teknologi ini telah menjadi bagian tak terpisahkan dari dunia pengembangan modern. Namun, bagi pemula, memahami perintah-perintah dasar Git bisa terasa menakutkan. Jangan khawatir! Dalam artikel ini, kita akan menjelajahi perintah-perintah penting Git dan GitHub melalui studi kasus sederhana yang akan membantu Anda memahami konsep-konsep ini dengan lebih baik.\n\n## Studi Kasus: Proyek Website Portofolio\n\nBayangkan Anda adalah seorang pengembang web pemula yang ingin membuat website portofolio. Anda telah memutuskan untuk menggunakan Git untuk mengelola kode Anda dan GitHub untuk menyimpan proyek Anda secara online. Mari kita lihat bagaimana perintah-perintah Git dapat membantu Anda dalam perjalanan ini.\n\n### 1. Git Init: Memulai Perjalanan\n\n```javascript\ngit init\n```\nPerintah ini akan membuat repositori Git baru di folder Anda. Sekarang Anda siap untuk mulai melacak perubahan pada proyek Anda!\n\n### 2. Git Add: Menyiapkan Perubahan\n\nSetelah membuat beberapa file HTML dan CSS untuk website Anda, saatnya untuk menambahkan file-file tersebut ke area staging. Gunakan perintah:\n\n```javascript\ngit add .\n```\nTanda titik (.) berarti Anda menambahkan semua file baru dan yang dimodifikasi ke area staging. Jika Anda hanya ingin menambahkan file tertentu, ganti tanda titik dengan nama file, misalnya git add index.html \n\n### 3. Git Commit: Menyimpan Perubahan\n\nSekarang file-file Anda sudah berada di area staging, saatnya untuk membuat commit. Commit adalah cara Git untuk menyimpan snapshot dari proyek Anda pada titik waktu tertentu. Gunakan perintah:\n\n```javascript\ngit commit -m "Menambahkan halaman utama dan stylesheet"\n```\nPesan dalam tanda kutip adalah deskripsi singkat tentang perubahan yang Anda buat. Usahakan untuk membuat pesan commit yang jelas dan deskriptif.\n\n### 4. Git Remote: Menghubungkan ke GitHub\n\nSekarang Anda ingin menyimpan proyek Anda di GitHub. Pertama, buat repositori baru di GitHub. Kemudian, hubungkan repositori lokal Anda dengan repositori GitHub menggunakan perintah:\n\n```javascript\ngit remote add origin https://github.com/username/nama-repo.git\n```\nGanti username dan nama-repo dengan informasi repositori GitHub Anda.\n\n### 5. Git Push: Mengunggah ke GitHub\n\nUntuk mengunggah commit Anda ke GitHub, gunakan perintah:\n\n```javascript\ngit push -u origin main\n```\nPerintah ini akan mengirim semua commit Anda ke branch main di repositori GitHub Anda.\n\n### 6. Git Pull: Mengambil Pembaruan\n\nMisalkan Anda bekerja di komputer lain dan ingin mengambil versi terbaru dari proyek Anda dari GitHub. Gunakan perintah:\n\n```javascript\ngit pull origin main\n```\nPerintah ini akan mengambil dan menggabungkan perubahan dari repositori GitHub ke repositori lokal Anda.\n\n### 7. Git Fetch: Memeriksa Pembaruan\n\nJgit fetch originika Anda hanya ingin melihat perubahan tanpa langsung menggabungkannya, gunakan:\n\n```javascript\ngit fetch origin\n```\nPerintah ini akan mengambil informasi tentang perubahan di repositori remote tanpa menggabungkannya ke repositori lokal Anda.\n\n## Tips dan Praktik Terbaik\n\n- Commit Sering: Buatlah commit kecil dan sering. Ini memudahkan pelacakan perubahan dan pemecahan masalah.\n- Gunakan Branch: Untuk fitur baru atau eksperimen, buatlah branch terpisah dengan git branch nama-branch.\n- Review Sebelum Commit: Gunakan git status dan git diff untuk memeriksa perubahan sebelum melakukan commit.\n- Tulis Pesan Commit yang Baik: Jelaskan apa dan mengapa dalam pesan commit Anda.\n- Gunakan .gitignore: Buat file .gitignore untuk mengabaikan file yang tidak perlu dilacak oleh Git.\n## Kesimpulan\n\nDengan memahami perintah-perintah dasar Git dan GitHub ini, Anda telah memiliki fondasi yang kuat untuk mengelola proyek pengembangan Anda. Ingatlah bahwa praktek adalah kunci. Jangan ragu untuk bereksperimen dengan repositori uji coba untuk membiasakan diri dengan alur kerja Git.\n\nGit dan GitHub mungkin terlihat rumit pada awalnya, tetapi dengan latihan, Anda akan menemukan bahwa alat-alat ini sangat berharga dalam perjalanan Anda sebagai pengembang. Selamat mencoba, dan semoga sukses dengan proyek-proyek Anda!\n	https://res.cloudinary.com/diqabuwwk/image/upload/v1725888342/WISATA/file_wotljd.jpg	116729146132809119225	5f53d268-6c45-4557-938e-2eb0c1d83daa	menguasai-perintah-dasar-git-dan-github-panduan-praktis-untuk-pemula	2024-09-09 13:25:42.782	2024-09-09 13:25:42.782	Artikel ini membahas perintah-perintah dasar Git dan GitHub melalui studi kasus pengembangan website portofolio. Ditulis dengan gaya praktis dan mudah dipahami, artikel ini menjelaskan cara menggunakan git init, git add, git commit, git push, git pull, dan git fetch, serta memberikan tips dan praktik terbaik dalam menggunakan Git untuk pemula. Cocok untuk pengembang web yang baru mulai belajar Git dan ingin mengelola proyek mereka secara lebih efektif dengan GitHub.
15b5441c-9348-4e9c-b74c-843fb4a2ee86	Memaksimalkan Kolaborasi Tim dengan GitHub: Panduan Praktis untuk Pengembangan Bersama	Dalam era pengembangan perangkat lunak modern, kolaborasi tim menjadi kunci kesuksesan proyek. GitHub, platform hosting repositori Git terkemuka, telah menjadi tempat berkumpulnya para pengembang untuk berkolaborasi secara efektif. Artikel ini akan membahas cara memaksimalkan kolaborasi tim menggunakan fitur-fitur GitHub, disertai dengan praktik terbaik yang dapat Anda terapkan dalam proyek Anda.\n\n## Mengapa GitHub Menjadi Pilihan Utama untuk Kolaborasi?\n\nGitHub bukan sekadar tempat menyimpan kode. Platform ini menawarkan berbagai fitur yang memudahkan tim untuk bekerja bersama, melacak perubahan, dan mengelola proyek dengan lebih efisien. Mari kita jelajahi fitur-fitur utama dan cara memanfaatkannya.\n\n### 1. Forking dan Pull Requests: Jantung Kolaborasi GitHub\n\nForking memungkinkan Anda membuat salinan repositori orang lain di akun GitHub Anda. Ini adalah langkah awal yang sempurna untuk berkontribusi pada proyek open source atau bekerja pada fitur baru tanpa mengganggu kode utama.\n\n![fork.pngImages](https://res.cloudinary.com/diqabuwwk/image/upload/v1725889160/WISATA/file_ugwg8p.png)\n\nPraktik Terbaik:\n\n- Fork repositori utama ke akun Anda\n- Buat branch baru untuk fitur atau perbaikan yang Anda kerjakan\n- Setelah selesai, ajukan pull request ke repositori asal\nPull request adalah cara Anda mengusulkan perubahan ke repositori asal. Ini membuka pintu untuk diskusi dan review kode sebelum perubahan diintegrasikan \n\n### 2. Issues: Melacak Tugas dan Bug dengan Efektif\n\nIssues di GitHub bukan sekadar untuk melaporkan bug. Fitur ini bisa menjadi pusat diskusi tim tentang fitur baru, perbaikan, atau ide pengembangan.\n\n![issue.pngImages](https://res.cloudinary.com/diqabuwwk/image/upload/v1725889267/WISATA/file_dfz3si.png)\n\nPraktik Terbaik:\n\n- Gunakan label untuk mengkategorikan issues (misalnya: bug, enhancement, discussion)\n- Assign issues ke anggota tim yang bertanggung jawab\n- Gunakan milestone untuk mengelompokkan issues terkait dalam satu tujuan proyek\nTips Humanis:\n\n## 3. Open Pull Request: Memulai Diskusi Kolaboratif\n\nSetelah Anda membuat perubahan pada fork repositori dan siap untuk mengusulkannya ke repositori utama, saatnya untuk membuka pull request.\n\nStudi Kasus: Misalkan Anda telah menambahkan fitur baru untuk menampilkan profil pengguna di website portofolio tim. Setelah menyelesaikan pengembangan dan melakukan commit, Anda siap untuk mengajukan pull request.\n\n![pull_req.pngImages](https://res.cloudinary.com/diqabuwwk/image/upload/v1725889586/WISATA/file_qavt7a.png)\n\nLangkah-langkah:\n\n- Buka pull request dari branch fitur Anda ke branch utama repositori.\n- Berikan judul dan deskripsi yang jelas tentang apa yang Anda ubah dan mengapa.\n- Tag anggota tim yang mungkin perlu me-review perubahan Anda.\n![pull_req2.pngImages](https://res.cloudinary.com/diqabuwwk/image/upload/v1725889663/WISATA/file_nsyily.png)\n\n## 4. Review Pull Request: Memberikan Umpan Balik yang Konstruktif\n\nSetelah Anda membuka pull request, anggota tim lain dapat memeriksa dan memberikan umpan balik pada perubahan Anda.\n\nStudi Kasus: Seorang anggota tim mereview pull request Anda untuk menambahkan fitur profil pengguna. Dia menemukan beberapa masalah dalam implementasi dan memberikan komentar.\n\nLangkah-langkah:\n\n- Tinjau kode yang diubah dengan saksama.\n- Buat komentar inline untuk memberikan saran perbaikan yang spesifik.\n- Diskusikan solusi yang mungkin dalam komentar pull request.\n- Minta penjelasan lebih lanjut jika ada yang kurang jelas.\n## 5. Merge Pull Request: Menggabungkan Perubahan ke Kode Utama\n\nSetelah pull request disetujui dan di-review, saatnya untuk menggabungkan perubahan ke branch utama.\n\nStudi Kasus: Setelah melalui beberapa iterasi review, pull request Anda untuk menambahkan fitur profil pengguna telah disetujui. Sekarang Anda siap untuk menggabungkannya ke branch utama.\n\nLangkah-langkah:\n\n- Pastikan Anda telah menyelesaikan semua komentar review.\n- Lakukan "rebase" atau "merge" branch Anda ke branch utama.\n- Selesaikan konflik, jika ada, dengan hati-hati.\n- Klik tombol "Merge pull request" untuk menggabungkan perubahan.\n![pull_req2.pngImages](https://res.cloudinary.com/diqabuwwk/image/upload/v1725889948/WISATA/file_f7rr44.png)\n\n![after_merge.pngImages](https://res.cloudinary.com/diqabuwwk/image/upload/v1725889983/WISATA/file_wqounf.png)\n\nSetelah melakukan merge dalam pull request.\n\n## 6. Solved Conflict: Menangani Konflik saat Menggabungkan Perubahan\n\nTerkadang, saat Anda mencoba menggabungkan perubahan, Git dapat menemukan konflik antara versi yang berbeda dari file yang sama. Ini perlu diselesaikan secara manual.\n\nStudi Kasus: Saat Anda mencoba menggabungkan pull request untuk fitur profil pengguna, Git mendeteksi konflik pada file index.html. Dua anggota tim telah membuat perubahan pada bagian yang sama.\n\nLangkah-langkah:\n\n- Buka file yang mengalami konflik dan lihat bagian yang bertentangan.\n- Diskusikan dengan anggota tim lain untuk menentukan solusi terbaik.\n- Edit file untuk menyelesaikan konflik secara manual.\n- Tambahkan file yang telah diselesaikan ke staging dan lakukan commit baru.\n- Lanjutkan proses penggabungan pull request.\nDengan menguasai langkah-langkah ini, Anda akan dapat berkolaborasi dengan tim Anda secara efektif menggunakan GitHub. Ingatlah untuk selalu berkomunikasi dengan jelas, memberikan umpan balik yang konstruktif, dan memecahkan masalah bersama-sama.\n\n## Membangun Budaya Kolaborasi yang Kuat\n\nAlat seperti GitHub memang penting, tapi ingatlah bahwa kolaborasi yang sukses lebih dari sekadar teknologi. Ini tentang membangun budaya tim yang mendukung kerja sama dan komunikasi terbuka.\n\nTips untuk Membangun Budaya Kolaboratif:\n\n- Dokumentasi yang Baik: Buatlah README.md yang informatif dan selalu perbarui dokumentasi proyek.\n- Komunikasi Terbuka: Dorong diskusi di issues dan pull requests. Tidak ada pertanyaan yang "terlalu sederhana" untuk ditanyakan.\n- Mentoring: Pasangkan anggota tim yang lebih berpengalaman dengan yang baru untuk transfer pengetahuan.\n- Celebrate Small Wins: Akui kontribusi setiap anggota tim, sekecil apapun itu.\n- Retrospektif Rutin: Adakan pertemuan tim secara berkala untuk membahas apa yang berjalan baik dan apa yang bisa diperbaiki dalam proses kolaborasi.\n## Kesimpulan\n\nKolaborasi menggunakan GitHub bukan hanya tentang menguasai alat, tapi juga membangun hubungan dan praktik kerja yang efektif dalam tim. Dengan memanfaatkan fitur-fitur GitHub secara optimal dan menerapkan praktik-praktik terbaik yang telah kita bahas, Anda dapat meningkatkan produktivitas tim dan kualitas proyek secara signifikan.\n\nIngatlah bahwa setiap tim unik, jadi jangan ragu untuk bereksperimen dan menemukan cara kerja yang paling cocok untuk tim Anda. Yang terpenting, nikmati proses kolaborasi ini. Selamat berkarya bersama menggunakan GitHub!\n	https://res.cloudinary.com/diqabuwwk/image/upload/v1725890107/WISATA/file_o2vufu.png	116729146132809119225	5f53d268-6c45-4557-938e-2eb0c1d83daa	memaksimalkan-kolaborasi-tim-dengan-github-panduan-praktis-untuk-pengembangan-bersama	2024-09-09 13:55:08.111	2024-09-09 13:55:08.111	Artikel ini membahas cara memaksimalkan kolaborasi tim menggunakan GitHub, dengan fokus pada fitur-fitur penting seperti forking, pull requests, issues, projects, code reviews, dan GitHub Actions. Ditulis dalam gaya yang humanis dan praktis, artikel ini juga memberikan tips untuk membangun budaya kolaboratif yang kuat dalam tim, serta praktik terbaik untuk meningkatkan efisiensi kerja. 
26a5d874-b8a9-4491-b7f3-108e9866e72a	Implementasi Struktur Data Stack di Python	Artikel ini membahas cara mengimplementasikan struktur data stack di Python dengan menerapkan praktik terbaik, seperti penanganan error, pengelolaan kapasitas stack, serta contoh penggunaan stack dalam kehidupan nyata. Salah satu contoh aplikasi stack yang akan dibahas adalah membalikkan array, yang menunjukkan sifat Last-In-First-Out (LIFO) pada stack.\n\nStack adalah salah satu konsep mendasar dalam struktur data yang banyak digunakan dalam algoritma, seperti depth-first search (DFS), proses rekursi, dan pengelolaan undo/redo pada aplikasi. Menguasai implementasi stack di Python akan memberi Anda fondasi kuat dalam mengelola data secara efisien.\n\n# Apa itu Stack?\n\nStack adalah kumpulan data yang terurut di mana penambahan dan penghapusan elemen selalu dilakukan di ujung yang sama, yang disebut top. Stack mengikuti prinsip LIFO (Last-In-First-Out), yang berarti elemen terakhir yang ditambahkan adalah elemen pertama yang dihapus.\n\n### Karakteristik Utama Stack:\n\n- Struktur LIFO: Elemen yang paling akhir ditambahkan akan dikeluarkan pertama kali.\n- Dua Operasi Utama:Push: Menambahkan elemen ke atas stack.Pop: Menghapus elemen dari puncak stack.\n- Push: Menambahkan elemen ke atas stack.\n- Pop: Menghapus elemen dari puncak stack.\nStack banyak digunakan dalam berbagai algoritma, seperti manajemen memori dalam pemanggilan fungsi, penelusuran pohon, dan banyak lagi.\n\n# Operasi pada Stack\n\nBerikut ini adalah cara mengimplementasikan struktur data stack di Python menggunakan pendekatan berbasis kelas yang mencakup operasi dasar stack.\n\n### Implementasi Kelas Stack\n\n```javascript\nclass StackFullError(Exception):\n    """Exception yang dilemparkan ketika menambah elemen ke stack yang penuh."""\n    pass\n\nclass StackEmptyError(Exception):\n    """Exception yang dilemparkan ketika menghapus elemen dari stack yang kosong."""\n    pass\n\nclass Stack:\n    def __init__(self, kapasitas):\n        self.items = []\n        self.kapasitas = kapasitas\n\n    def is_empty(self):\n        return len(self.items) == 0\n\n    def is_full(self):\n        return len(self.items) >= self.kapasitas\n\n    def push(self, item):\n        if self.is_full():\n            raise StackFullError("Stack penuh, tidak dapat menambahkan elemen lagi.")\n        self.items.append(item)\n\n    def pop(self):\n        if self.is_empty():\n            raise StackEmptyError("Stack kosong, tidak dapat menghapus elemen.")\n        return self.items.pop()\n\n    def peek(self):\n        if self.is_empty():\n            raise StackEmptyError("Stack kosong, tidak ada elemen untuk dilihat.")\n        return self.items[-1]\n\n    def size(self):\n        return len(self.items)\n```\nDalam kelas ini:\n\n- Kami menggunakan dua exception khusus, yaitu StackFullError dan StackEmptyError, untuk menangani operasi yang tidak valid, seperti menambah elemen ke stack penuh atau menghapus elemen dari stack yang kosong.\n- Stack memiliki kapasitas tetap untuk memastikan stack tidak terus bertambah tanpa batas.\n- Operasi seperti push(), pop(), peek(), is_empty(), dan is_full() mencakup semua operasi dasar stack.\nContoh Penggunaan:\n\n```javascript\nstack = Stack(4)\nstack.push(1)\nstack.push(2)\nstack.push(3)\nstack.push(4)\n\nprint("Stack setelah push: ", stack.items)\n\nprint("Item yang dihapus: ", stack.pop())\nprint("Stack setelah pop: ", stack.items)\n\nprint("Item teratas: ", stack.peek())\nprint("Ukuran stack: ", stack.size())\n\n```\nContoh ini menunjukkan cara:\n\n- Membuat stack dengan kapasitas 4.\n- Menambahkan (push) dan menghapus (pop) elemen dari stack.\n- Melihat elemen teratas (peek) dan memeriksa ukuran stack.\n## Penanganan Stack Overflow dan Stack Underflow\n\nKetika bekerja dengan struktur data seperti stack, penting untuk menangani kesalahan seperti overflow (menambah elemen ke stack yang penuh) dan underflow (menghapus elemen dari stack yang kosong) dengan benar.\n\n### StackFullError\n\nException ini dilemparkan ketika kita mencoba menambah elemen ke stack yang sudah penuh. Hal ini mencegah stack menerima elemen tambahan yang melampaui kapasitasnya.\n\n### StackEmptyError\n\nException ini dilemparkan ketika kita mencoba menghapus atau melihat elemen dari stack yang kosong. Hal ini mencegah operasi yang tidak valid yang dapat mengganggu alur program.\n\n```javascript\ntry:\n    stack.push(5)  # Ini akan menimbulkan StackFullError\nexcept StackFullError as e:\n    print(e)\n\ntry:\n    empty_stack = Stack(3)\n    empty_stack.pop()  # Ini akan menimbulkan StackEmptyError\nexcept StackEmptyError as e:\n    print(e)\n\n```\n## Membalikkan Array Menggunakan Stack\n\nSalah satu aplikasi praktis stack adalah untuk membalikkan data. Karena stack mengikuti prinsip LIFO, jika kita memasukkan semua elemen array ke dalam stack, dan kemudian mengeluarkannya kembali, urutannya akan dibalik.\n\n### Fungsi untuk Membalikkan Array\n\n```javascript\ndef reverse_array(arr):\n    stack = Stack(len(arr))  # Inisialisasi stack dengan ukuran array\n    \n    # Masukkan semua elemen ke dalam stack\n    for item in arr:\n        stack.push(item)\n\n    # Keluarkan semua elemen dari stack untuk mendapatkan urutan terbalik\n    reversed_arr = []\n    while not stack.is_empty():\n        reversed_arr.append(stack.pop())\n\n    return reversed_arr\n\n```\n### Contoh Penggunaan\n\n```javascript\ninput_arr = [1, 2, 3, 4]\nprint(f"Array asli: {input_arr}")\nprint(f"Array yang dibalik: {reverse_array(input_arr)}")\n\n```\nContoh ini mengambil array [1, 2, 3, 4], memasukkan semua elemennya ke dalam stack, lalu mengeluarkannya untuk membentuk array terbalik [4, 3, 2, 1].\n\n### Penjelasan\n\n- Fase Push: Semua elemen array dimasukkan ke dalam stack sesuai urutan awal.\n- Fase Pop: Karena sifat LIFO stack, elemen pertama yang dikeluarkan adalah elemen terakhir yang dimasukkan, sehingga menghasilkan array yang dibalik\n## Kesimpulan\n\nPada artikel ini, kita telah membahas implementasi struktur data stack di Python dengan menerapkan praktik terbaik, seperti manajemen kapasitas dan penanganan error. Kita juga telah melihat bagaimana stack dapat digunakan untuk membalikkan array, salah satu aplikasi praktis dari stack.\n\nPemahaman tentang stack penting dalam banyak algoritma dan dapat menjadi alat yang berguna dalam menyelesaikan berbagai masalah. Baik itu untuk mengelola pemanggilan fungsi, operasi undo, atau membalikkan data, stack menawarkan solusi yang efisien. Dengan menerapkan teknik-teknik ini di Python, Anda dapat memperdalam pemahaman tentang struktur data dan penerapannya di dunia nyata.\n\nSALAM DATA SALAM ADYTAMA\n\n\n	https://res.cloudinary.com/diqabuwwk/image/upload/v1727781131/WISATA/file_ve05vg.jpg	116729146132809119225	5f53d268-6c45-4557-938e-2eb0c1d83daa	implementasi-struktur-data-stack-di-python	2024-10-01 11:12:12.401	2024-10-01 11:12:12.401	Artikel ini membahas secara mendalam implementasi struktur data stack di Python, dengan penekanan pada praktik terbaik seperti penanganan error, pengelolaan kapasitas, dan penggunaan stack dalam membalikkan array
d7c3d440-32ec-4f74-a556-bdf5c9d12098	Visualisasi Data yang Interaktif Menggunakan Plotly Express	Halo, sobat data! Pasti kalian sudah tidak asing dengan Visualisasi Data , nah kali ini aku mau share nih salah satu tools yang menurut aku powerfull dalam pembuatan visualisasi data yang interaktf di python Yuk, kita bahas bareng-bareng!\n\n# Apasih itu Visualisasi Data dan mengapa sangat penting bagi seorang data science ?\n\nVisualisasi data adalah proses representasi informasi atau data dalam bentuk grafis, seperti grafik, diagram, peta, dan bagan, untuk memudahkan pemahaman pola, tren, dan wawasan dari data tersebut. Dengan menggunakan elemen visual seperti titik, garis, batang, dan warna, visualisasi data membantu mempercepat pemahaman dan analisis data yang kompleks, sehingga memudahkan pengambilan keputusan.\n\n# Apa itu plotly ?\n\nPlotly Express adalah visualisasi tingkat tinggi, sebuah library Python yang digunakan untuk membuat visualisasi data interaktif. Plotly Express memungkinkan pembuatan grafik yang kompleks dengan sedikit kode, menjadikannya ideal untuk eksplorasi data cepat.\n\n# Beberapa Fitur yang ada di plotly\n\nBerikut adalah beberapa fitur utama dari Plotly Express:\n\n- Kemudahan Penggunaan: Dengan sintaks yang sederhana, Plotly Express memungkinkan pengguna membuat berbagai jenis grafik hanya dengan beberapa baris kode.\n- Beragam Grafik: Plotly Express mendukung berbagai jenis visualisasi seperti grafik garis, grafik batang, scatter plot, peta, histogram, box plot, dan banyak lagi.\n- Integrasi dengan Pandas: Plotly Express bekerja sangat baik dengan DataFrame dari Pandas, memungkinkan pengguna untuk membuat grafik langsung dari data yang terstruktur.\n- Interaktif: Grafik yang dibuat dengan Plotly Express bersifat interaktif, sehingga pengguna dapat memanipulasi grafik secara langsung, seperti melakukan zoom, pan, dan memilih data yang ditampilkan.\n- Fleksibilitas: Meskipun Plotly Express dirancang untuk kesederhanaan, grafik yang dihasilkan dapat disesuaikan lebih lanjut menggunakan library Plotly utama untuk kebutuhan visualisasi yang lebih kompleks.\n# Cara penggunaan plotly untuk visualisasi\n\npertama kalian harus import library plotly terlebih dahulu\n\n```javascript\npip install plotly\n\n```\nsetelah itu import library plotly\n\n```javascript\nimport plotly.express as px\n\n```\nnah sekarang mari kita coba untuk melakukan visualisasi \n\ndisini aku menggunakan contoh data sederhana.\n\n```javascript\n# pertama kita definisikan datanya terlebih dahulu\ndata = {\n    'species': ['Setosa', 'Versicolor', 'Virginica'],\n    'count': [50, 45, 55]\n}\n\n```\n```javascript\n# kemudian kita ubah menjadi dataframe dari data\ndf = pd.DataFrame(data)\n\n```\n```javascript\n# selanjutnya membuat barchart nya seperti fungsi di bawah\nfig = px.bar(df, x='species', y='count', title='Total Spesies')\n\n```\n```javascript\n# kemudian tampilkan grafiknya\nfig.show()\n\n```\n\n\nnah hasinya kurang lebih seperti ini dan jika kita mengarahkan cursor pada bagian barchart maka akan muncul informasi seperti nama spesiesnya dan jumlah nya\n\nselanjutnya kita contohkan pada grafik yang berbeda\n\nkita contohkan masih menggunakan data sebelumnya\n\n```javascript\n# Membuat visualisasi pie chart\nfig = px.pie(df, names='species', values='count', title='Total Spesies')\n\n```\n```javascript\n# Menampilkan grafik\nfig.show()\n\n```\n\n\nSelain itu juga kita bisa langsung mengunduh hasil visualisasi yang sudah kita buat pada icon yang berada di pojok kanan atas\n\n\n\n# Kesimpulan\n\nJadi gimana nih sobat data? tertarik juga menggunakan plotly? langsung saja eksplor dunia visualisasi data yang mengasikkan ini!!\n\nDan jadilah master di bidang yang kamu sukai!!!\n	https://res.cloudinary.com/diqabuwwk/image/upload/v1725081947/WISATA/file_wmk3fm.jpg	110859962141543654662	c50cca72-d4e3-4d2f-9055-92e9ddac3dc6	visualisasi-data-yang-interaktif-menggunakan-plotly-express	2024-08-31 05:25:49.508	2024-08-31 15:35:09.137	Visualisasi data adalah salah satu keterampilan penting bagi seorang data scientist. Artikel ini memperkenalkan Plotly, sebuah library Python yang mempermudah pembuatan grafik interaktif dengan hanya beberapa baris kode. 
f457e512-9f23-4f25-b44e-e77c25ebf63c	Mengenal Git & GitHub: Panduan Sederhana untuk Pemula	Pernahkah Anda merasa frustrasi saat bekerja pada proyek bersama teman-teman, di mana file terus berubah dan Anda kesulitan melacak siapa yang mengubah apa? Atau mungkin Anda pernah tidak sengaja menghapus bagian penting dari kode Anda dan berharap bisa kembali ke versi sebelumnya? Jika ya, tenang saja! Ada solusi untuk masalah-masalah ini, dan namanya adalah Git dan GitHub.\n\n# Apa itu Git?\n\nGit adalah seperti mesin waktu untuk kode Anda. Bayangkan Anda sedang menulis sebuah cerita. Setiap kali Anda menyelesaikan satu bab, Anda menyimpan salinannya. Dengan Git, Anda bisa melakukan hal yang sama dengan kode Anda. Setiap perubahan yang Anda buat disimpan sebagai "snapshot", sehingga Anda bisa kembali ke versi sebelumnya kapan saja.\n\n## Mengapa Git Penting?\n\n- Pelacakan Perubahan: Git memungkinkan Anda melihat siapa yang mengubah apa dan kapan.\n- Kolaborasi: Bekerja bersama tim menjadi lebih mudah karena setiap orang bisa melihat dan menggabungkan perubahan.\n- Backup: Kode Anda aman tersimpan, bahkan jika komputer Anda rusak.\n# Apa itu GitHub?\n\nJika Git adalah mesin waktu, maka GitHub adalah perpustakaan online tempat Anda menyimpan mesin waktu tersebut. GitHub adalah platform berbasis web yang menggunakan Git, memungkinkan Anda untuk menyimpan proyek-proyek Anda secara online dan berkolaborasi dengan orang lain dari seluruh dunia.\n\n## Keunggulan GitHub:\n\n- Berbagi Kode: Anda bisa menunjukkan karya Anda kepada dunia.\n- Belajar dari Orang Lain: Lihat bagaimana programmer lain menyelesaikan masalah.\n- Kontribusi: Anda bisa membantu proyek open-source yang Anda sukai.\n# Memulai dengan Git & GitHub\n\n### Langkah 1: Instalasi Git\n\nPertama, unduh dan instal Git dari situs resmi . Prosesnya mirip dengan menginstal aplikasi lain di komputer Anda.\n\n### Langkah 2: Buat Akun GitHub\n\nKunjungi dan buat akun gratis. Ini seperti membuat akun media sosial, tapi untuk kode!\n\n### Langkah 3: Buat Repository Pertama Anda\n\n- Di GitHub, klik tombol "+" di pojok kanan atas dan pilih "New repository".\n- Beri nama repositori Anda, misalnya "proyek-pertamaku".\n\n\n- Klik "Create repository".\nSelamat! Anda baru saja membuat rumah online pertama untuk proyek Anda.\n\n### Langkah 4: Clone Repository ke Komputer Anda\n\nSekarang, mari bawa proyek online Anda ke komputer:\n\n- Buka terminal atau command prompt.\n- Ketik\n```javascript\ngit clone https://github.com/[username-anda]/proyek-pertamaku.git\n\n```\nnote: ganti username-anda dengan username Github anda.\n\n- Tekan Enter.Voila! Proyek Anda sekarang ada di komputer Anda.\n## Tips untuk Pemula\n\n- Commit Sering: Simpan perubahan Anda secara teratur. Ini seperti menyimpan dokumen saat menulis.\n- Tulis Pesan Commit yang Jelas: Jelaskan apa yang Anda ubah. Ini akan membantu Anda (dan orang lain) nanti.\n- Jangan Takut Bereksperimen: Dengan Git, Anda selalu bisa kembali ke versi sebelumnya jika ada kesalahan.\n- Gunakan README: Buat file README.md di repositori Anda untuk menjelaskan proyek Anda kepada orang lain.\n# Kesimpulan\n\nGit dan GitHub mungkin terlihat menakutkan pada awalnya, tapi dengan sedikit latihan, mereka akan menjadi alat yang tak tergantikan dalam perjalanan coding Anda. Ingat, setiap programmer hebat pernah menjadi pemula. Jadi, jangan ragu untuk memulai dan terus belajar!\n\nSelamat mencoba, dan selamat menjelajahi dunia Git dan GitHub!\n\nSALAM DATA SALAM ADYATAMA\n	https://res.cloudinary.com/diqabuwwk/image/upload/v1725041469/WISATA/file_csxion.png	116729146132809119225	5f53d268-6c45-4557-938e-2eb0c1d83daa	mengenal-git-github-panduan-sederhana-untuk-pemula	2024-08-30 18:11:10.304	2024-08-31 15:36:07.205	Pernah merasa kesulitan melacak perubahan pada proyek atau ingin kembali ke versi kode sebelumnya? Git dan GitHub hadir sebagai solusi! Artikel ini menjelaskan bagaimana Git berfungsi sebagai mesin waktu untuk kode Anda, serta bagaimana GitHub memudahkan kolaborasi dan penyimpanan proyek secara online. 
445f2931-ee90-437a-8f2b-8c5799043fc9	Pandas: Si Jagoan Data di Python yang Wajib Kamu Kenal!	Halo, sobat data! Sudah pernah dengar tentang Pandas? Bukan, bukan panda yang imut dan menggemaskan itu, tapi Pandas library di Python. Penasaran? Yuk, kita bahas bareng-bareng!\n\n# Apa Sih Pandas Itu?\n\nPandas itu seperti pisau Swiss untuk data di Python. Dia bisa melakukan banyak hal, mulai dari membaca data, mengolahnya, sampai menganalisisnya. Kalau kamu suka main Excel, bayangkan Pandas sebagai Excel-nya Python, tapi jauh lebih keren dan powerful!\n\n# Kenapa Harus Pakai Pandas?\n\n- Cepat dan Efisien: Pandas bisa menangani data besar dengan cepat.\n- Fleksibel: Bisa handle berbagai jenis data, dari CSV sampai SQL.\n- Banyak Fitur: Punya banyak fungsi bawaan yang bikin hidup kita lebih mudah.\n- Populer: Banyak digunakan di dunia data science, jadi belajarnya pasti berguna\n# Struktur Data Utama di Pandas\n\nAda dua struktur data utama di Pandas yang wajib kamu kenal:\n\n- Series: Bayangkan ini seperti satu kolom di Excel. Cocok untuk data 1 dimensi.\n- DataFrame: Nah, kalau ini seperti tabel lengkap di Excel. Bisa punya banyak kolom dan baris.\n## Cara Mulai Pakai Pandas\n\nPertama-tama, pastikan kamu sudah install Pandas ya. Bisa pakai pip:\n\n```javascript\npip install pandas\n\n```\nTerus, di script Python-mu, jangan lupa import:\n\n```javascript\nimport pandas as pd\n\n```\nNah, sekarang kamu udah siap jelajah dunia Pandas!\n\n## Contoh Penggunaan Pandas yang Keren\n\n- Baca File CSV\n```javascript\ndf = pd.read_csv('data_keren.csv')\n\n```\ndengan pandas kalian bisa membaca dan mengelolahan file dengan mudah!\n\n- Lihat Data Awal\n```javascript\nprint(df.head())\n\n```\ndengan menuliskan code diatas  kalian bisa melihat data 5 teratas.\n\n- Hitung Rata-rata\n```javascript\nrata_rata = df['kolom_angka'].mean()\n\n```\ndengan mengunakan perintah mean kita bisa langsung melihat rata-rata dari data.\n\n- Filter Data\n```javascript\ndata_filtered = df[df['umur'] > 25]\n\n```\ndengan menulisakan perintah diatas kita bisa mencari data yang hanya berumur lebih dari 25\n\n- Grouping dan Agregasi\n```javascript\nhasil = df.groupby('kota')['pendapatan'].mean()\n\n```\ndengan hanya perintah diatas kita bisa melihat rata-rata pendapatan dikelompokan berdasarkan kotanya.\n\nGimana? mudah bukan mengunakan pandas untuk mengelolah data?\n\n# Tips Jitu Belajar Pandas\n\n- Praktek, Praktek, Praktek: Jangan cuma baca, langsung coba di laptop!\n- Mulai dari Yang Simple: Jangan langsung tackle data besar. Mulai dari dataset kecil dulu.\n- Manfaatkan Dokumentasi: Pandas punya dokumentasi yang lengkap dan user-friendly.\n- Join Komunitas: Banyak forum dan grup yang membahas Pandas. Jangan malu bertanya!\n- Bikin Proyek Kecil: Coba analisis data yang kamu suka, misal data film atau musik.\n# Kesimpulan\n\nNah, gimana? Seru kan Pandas itu? Memang di awal mungkin terasa overwhelming, tapi percaya deh, sekali kamu jago Pandas, dunia data akan jadi mainanmu!\n\nIngat, setiap master pernah jadi pemula. Jadi, jangan takut untuk mulai belajar Pandas dari sekarang. Siapa tahu, beberapa bulan lagi kamu sudah jadi jagoan data yang bikin kagum teman-teman!\n\nSelamat belajar dan jangan lupa have fun dengan Pandas! 🐼📊\n\nSALAM DATA SALAM ADYATAMA\n	https://res.cloudinary.com/diqabuwwk/image/upload/v1725039630/WISATA/file_wkftcw.jpg	116729146132809119225	c50cca72-d4e3-4d2f-9055-92e9ddac3dc6	pandas-si-jagoan-data-di-python-yang-wajib-kamu-kenal	2024-08-30 17:40:33.25	2024-08-31 15:37:04.852	Pernah dengar tentang Pandas? Bukan panda hewan, tapi Pandas library di Python! Pandas adalah alat yang sangat powerful untuk mengolah dan menganalisis data, layaknya Excel versi Python, namun jauh lebih fleksibel dan cepat. 
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description, type) FROM stdin;
4d94570a-b052-45a1-bf2d-cafce16f3af6	Workshop	workshop	event
c50cca72-d4e3-4d2f-9055-92e9ddac3dc6	Sains Data	Sains Data	artikel
01786e8e-0409-4386-a55a-95a5889a3d8c	Web Devoloper	Membuat Paper Manager untuk iCSSF ITERA	portofolio
351b4a79-11e7-473e-a00b-99191bf2b223	Agenda	agenda	event
892a9c73-3395-49aa-ab70-65b6b18cd441	Marchendese	Marchendese HMSD	merchant
5f53d268-6c45-4557-938e-2eb0c1d83daa	Pemerograman	Pemerograman	artikel
\.


--
-- Data for Name: contents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contents (id, title, content, image, link_ig, "createdAt", "updatedAt") FROM stdin;
c9015d2e-9f3c-4c7d-9a14-2897e65b0b04	Grand Opening Website Himpunan Mahasiswa Sains Data	Launching website Himpunan Mahasiswa Sains Data	https://res.cloudinary.com/diqabuwwk/image/upload/v1725097244/WISATA/file_kgstpa.jpg	https://www.instagram.com/p/C_VAmtRJEfI/?utm_source=ig_web_copy_link	2024-08-31 09:38:41.556	2024-08-31 09:40:45.353
a86963b9-0c59-4a54-a510-507b3544ee5f	Penerimaan mahasiswa baru 	Penerima peserta didik baru 2024	https://res.cloudinary.com/diqabuwwk/image/upload/v1725097528/WISATA/file_jfcwoo.jpg	https://www.instagram.com/p/C8JtrI5JOG3/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==	2024-08-26 16:28:16.205	2024-08-31 09:45:29.512
052021a5-056f-4556-934a-6e785478f930	Wisuda Sains data	Wisuda Pertama Sains Data	https://res.cloudinary.com/diqabuwwk/image/upload/v1725097722/WISATA/file_xjlv1p.jpg	https://www.instagram.com/p/C9pDbbfpl0P/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==	2024-08-26 16:26:53.114	2024-08-31 09:48:43.475
365b5793-f993-4394-b122-52b89977d233	Qurban 2024	Kegiatan Kurban 	https://res.cloudinary.com/diqabuwwk/image/upload/v1725097878/WISATA/file_dk5eew.jpg	https://www.instagram.com/p/C8jynNMJurM/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==	2024-08-26 16:25:28.679	2024-08-31 09:51:19.62
34fb0378-b256-47c7-9a5f-b2a2dab222d6	Sekolah Sekretaris	Kegiatan Pelatihan Himpunan	https://res.cloudinary.com/diqabuwwk/image/upload/v1725097956/WISATA/file_eayq10.jpg	https://www.instagram.com/p/C87PUNXydN3/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==	2024-08-26 16:26:25.569	2024-08-31 09:52:37.249
eb3c2326-acdf-4574-acaa-fb375460d6f9	Datapudi	Kegiatan yang memperingati ulang tahun prodi 	https://res.cloudinary.com/diqabuwwk/image/upload/v1725098246/WISATA/file_gu6nkz.jpg	https://www.instagram.com/p/C87PUNXydN3/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==	2024-08-26 16:23:49.269	2024-08-31 09:57:27.337
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departments (id, name, short_name, description, logo, year, department_type) FROM stdin;
539d019c-ddae-47f5-904e-d655f2267451	Pengembangan Sumber Daya Anggota	PSDA	Departemen yang mempunyai tugas merumuskan kebijakan teknis, merencanakan, melaksanakan, membina, mengembangkan dan mengendalikan Pengelolaan Sumber Daya Anggota	https://res.cloudinary.com/diqabuwwk/image/upload/v1723978432/WISATA/file_x9epnf.png	2024	bph
d5b8df06-2409-463c-b3d2-b1f44426704b	Storage Sains Data	SSD	Departemen bidang yang mengembangkan potensi kewirausahaan mahasiswa dan menciptakan usaha-usaha kreatif organisasi	https://res.cloudinary.com/diqabuwwk/image/upload/v1723978861/WISATA/file_d1brne.png	2024	bph
71b84840-9957-4875-8cac-3711a661ca60	Media Kreatif	MEDKRAF	Departemen yang mengelola konten media dan kegiatan kreatif. Tugasnya mencakup produksi konten seperti artikel, foto, dan video; pengelolaan media sosial; desain grafis untuk materi promosi; serta penyelenggaraan acara kreatif. Dengan bertujuan meningkatkan visibilitas dan keterlibatan himpunan melalui komunikasi dan publikasi yang efektif.	https://res.cloudinary.com/diqabuwwk/image/upload/v1723998399/WISATA/file_xzxb0w.png	2024	bph
6a617094-d1f5-4838-843f-5790976ebd91	Akademik Dan Keprofesian	MIKFES	Departement yang bertugas untuk memfasilitasi akademik dan meningkatkan keterampilan keprofesian mahasiswa demi mewujudkan mahasiswa Sains Data yang berprestasi, berwawasan, hingga persiapan untuk dunia pasca kampus.	https://res.cloudinary.com/diqabuwwk/image/upload/v1723978233/WISATA/file_xkr8fu.png	2024	bph
4496ce0b-1054-4cb0-b127-26488eaec15c	Badan Legestatif	BALEG	Departemen yang bertugas merumuskan dan mengawasi kebijakan serta program kerja himpunan. Mereka menyusun kebijakan, memantau pelaksanaan program, dan mengadakan rapat untuk membahas isu-isu penting. Baleg Himpunan juga berfungsi sebagai perwakilan suara mahasiswa dan menjembatani komunikasi antara himpunan dengan pihak luar, serta menyerap aspirasi mahasiswa untuk diperhatikan dalam keputusan yang diambil	https://res.cloudinary.com/diqabuwwk/image/upload/v1723979112/WISATA/file_quzgjl.png	2024	baleg
0caaa47f-3c45-4f1f-91d2-f324f50a0deb	Eksternal	EKSTERNAL	Departemen yang mempunyai fungsi kerja sebagai penjaga hubungan baik dengan orang-orang maupun lembaga di luar keanggotaan	https://res.cloudinary.com/diqabuwwk/image/upload/v1723978310/WISATA/file_d8tpwj.png	2024	bph
829df915-e111-4992-9286-4e00f7fd159d	Internal 	INTERNAL	Departemen yang secara khusus mengurus dan menangani segala bentuk pengembangan dan perbaikan sumber daya atau anggota, memperat hubungan setiap anggota, serta merumuskan dan membentuk landasan dasar bagi semua pengurus dan anggota organisasi dalam menjalankan organisasi	https://res.cloudinary.com/diqabuwwk/image/upload/v1723978512/WISATA/file_uvcu62.png	2024	bph
eef7dd19-8737-48a6-9a76-b21e22c900f7	Senator 	SENATOR	Dapartemen perwakilan mahasiswa yang menyuarakan aspirasi dan kebutuhan di tingkat himpunan, berpartisipasi dalam pembentukan dan pengawasan kebijakan himpunan, serta menghubungkan himpunan dengan lembaga lain. Mereka juga bertindak sebagai advokat, mediator, dan pemimpin yang menjunjung etika serta akuntabilitas	https://res.cloudinary.com/diqabuwwk/image/upload/v1723998418/WISATA/file_bd3pzj.png	2024	senator
d7b8375a-988a-4d96-be68-b68885c93486	Kesekjenan	KESEKJENAN	Pengurus Inti Himpunan Sains Data Itera	https://res.cloudinary.com/diqabuwwk/image/upload/v1724680755/WISATA/file_mber7i.png	2024	bph
\.


--
-- Data for Name: divisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.divisions (id, name, department_id) FROM stdin;
241460d0-b779-47a5-b243-cd27a253a9a4	Survei dan Riset	6a617094-d1f5-4838-843f-5790976ebd91
a2172ddb-9392-4df1-89db-9989350e962e	Pusat Inovasi dan Kajian Akademik	6a617094-d1f5-4838-843f-5790976ebd91
fa03c74d-41ab-4824-83f3-0c3c50508500	Club dan komunitas	6a617094-d1f5-4838-843f-5790976ebd91
f46fddc8-39e2-4100-80d5-9351d3b6aece	Kaderisasi	539d019c-ddae-47f5-904e-d655f2267451
8a3528f4-d398-4d25-8bed-51ad97e7510c	Pengabdian Masyarakat	0caaa47f-3c45-4f1f-91d2-f324f50a0deb
17712a43-9a47-497c-b4c1-c37eafbd7fbe	Manajemen Minat dan Bakat	539d019c-ddae-47f5-904e-d655f2267451
d005d74b-fe75-4d9d-8631-865186a74dbb	Olahraga & Perlombaan	539d019c-ddae-47f5-904e-d655f2267451
b1cba988-19fc-41da-bebf-151b236f2eec	Kehamonisasian	829df915-e111-4992-9286-4e00f7fd159d
769f1c5d-8dde-4b20-8ca4-383a4277597e	Hubungan Luar	0caaa47f-3c45-4f1f-91d2-f324f50a0deb
09462714-d91f-4267-b520-84bab83ae0de	Kerohanian	829df915-e111-4992-9286-4e00f7fd159d
ef1725bd-e842-4ca5-a5de-adcef39fe162	Media & Konten	71b84840-9957-4875-8cac-3711a661ca60
d2666b7b-eff6-4851-b14f-70ab240b203f	PDD	71b84840-9957-4875-8cac-3711a661ca60
cb48c1a2-3a43-41b4-be39-8e6ed719d0c0	Visual Desain	71b84840-9957-4875-8cac-3711a661ca60
33998c2d-588f-4b30-8e3e-d841edca427a	Kewirausahaan	d5b8df06-2409-463c-b3d2-b1f44426704b
b9c6aed0-a234-4d63-afd3-438218d52f43	Komisi II Aspirasi dan Pengawasan	4496ce0b-1054-4cb0-b127-26488eaec15c
14d5c446-5283-4967-8c27-8165ee07761c	Sponsorship	d5b8df06-2409-463c-b3d2-b1f44426704b
270887b1-07a2-4a7e-9211-28b872ec57d0	Komisi I Legislatif	4496ce0b-1054-4cb0-b127-26488eaec15c
c15939f7-d77c-4763-9a58-2822c83b6f57	Komisi III Media Legislatif	4496ce0b-1054-4cb0-b127-26488eaec15c
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (id, title, description, thumbnail, link_ig, date_start, date_end, author_id, category_id) FROM stdin;
58bb1727-8be5-4c77-997c-1fddd1c0ed21	HMSD Tanggap Bencana 	Himpunan Mahasiswa Sains Data mengadakan agenda sumbangan untuk korban bencana banjir	https://res.cloudinary.com/diqabuwwk/image/upload/v1724685066/WISATA/file_m19ihd.jpg	https://www.instagram.com/p/C87PUNXydN3/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==	2024-08-26 15:07:04.28	2024-08-26 15:07:04.28	7510d9f6-1d2b-40b5-835d-43c45d6f4d6f	351b4a79-11e7-473e-a00b-99191bf2b223
3eb56721-e740-4fc8-9b3e-1a2f03d6f89c	Perlombaan Prodi Band UKMBSM 2024	Himpunan Sains Data mengikuti kegiatan lomba musik yang diadakan oleh UKM BSM 	https://res.cloudinary.com/diqabuwwk/image/upload/v1724685174/WISATA/file_ak1lqj.jpg	https://www.instagram.com/p/C87PUNXydN3/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==	2024-08-26 15:11:21.785	2024-08-26 15:11:21.785	7510d9f6-1d2b-40b5-835d-43c45d6f4d6f	351b4a79-11e7-473e-a00b-99191bf2b223
13ef614d-5069-4306-8d03-115bc9e83ff8	Ramadhan Manisnya Berbagi	Kegiatan bagi bagi takjil	https://res.cloudinary.com/diqabuwwk/image/upload/v1724685543/WISATA/file_rn8rih.jpg	https://www.instagram.com/p/C87PUNXydN3/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==	2024-08-26 15:18:24.371	2024-08-26 15:18:24.371	7510d9f6-1d2b-40b5-835d-43c45d6f4d6f	351b4a79-11e7-473e-a00b-99191bf2b223
3d390ee9-57d3-46d8-aa31-ef028f7d4204	Wawancara CA-STAFF	Kegiatan Himpunan untuk menerima badan kepengurusan baru	https://res.cloudinary.com/diqabuwwk/image/upload/v1724685825/WISATA/file_jkpzzr.jpg	https://www.instagram.com/p/C87PUNXydN3/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA==	2024-08-26 15:16:20.228	2024-08-26 15:16:20.228	7510d9f6-1d2b-40b5-835d-43c45d6f4d6f	351b4a79-11e7-473e-a00b-99191bf2b223
9e52a327-9d67-4ce1-ade7-638744ea9c3c	Sains Data Mengabdi - Minggu 1	Pada minggu pertama Sains Data Mengabdi, telah diadakan kegiatan sosialisasi dengan topik UMKM dan Pencegahan Stunting.	https://res.cloudinary.com/diqabuwwk/image/upload/v1725794035/WISATA/file_vwsdps.jpg	.	2024-09-07 17:00:00	2024-09-07 17:00:00	99e98391-9666-46cf-8ff6-9200e65a7a2e	351b4a79-11e7-473e-a00b-99191bf2b223
\.


--
-- Data for Name: kepengurusan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kepengurusan (year) FROM stdin;
2024
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.members (id, name, department_id, "position", link_ig, link_linkedin, motto, photo, division_id, year) FROM stdin;
7f008aa5-9ba4-42ad-96d9-e58e0d8cdd41	Allya Nurul Islami Pasha	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	f46fddc8-39e2-4100-80d5-9351d3b6aece	2024
ede44825-6049-440a-bdc8-b691b409caa7	Farahanum Afifah Ardiansyah	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	f46fddc8-39e2-4100-80d5-9351d3b6aece	2024
73185c4d-b564-4a0d-adaf-b51ea89767ff	M. Deriansyah Okutra 	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	f46fddc8-39e2-4100-80d5-9351d3b6aece	2024
594d04ca-642e-49bb-97e5-5737dced87ed	Eksanty F. Sukma Islamiaty	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	f46fddc8-39e2-4100-80d5-9351d3b6aece	2024
cd287627-8d0c-4ab8-9973-492eaf3dc0df	Oktavia Nurwenda Puspita Sari         	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	f46fddc8-39e2-4100-80d5-9351d3b6aece	2024
c8c946b4-8ed7-4cc1-9928-e94f3ae3f088	Ferdy Kevin Naibaho	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	f46fddc8-39e2-4100-80d5-9351d3b6aece	2024
14e7c5c0-cf51-44d9-ad04-c55630413fad	Johannes Krisjon Silitonga	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	17712a43-9a47-497c-b4c1-c37eafbd7fbe	2024
c739793c-b361-4f24-bf50-7c75a6e4e05f	Presilia	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	17712a43-9a47-497c-b4c1-c37eafbd7fbe	2024
dfed7db4-471c-4890-b0e3-e36b3e28cfa5	Rafa Aqilla Jungjunan	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	17712a43-9a47-497c-b4c1-c37eafbd7fbe	2024
e3ecbf9f-c033-4e5f-9222-b66ea1a0863f	Sahid Maulana	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	17712a43-9a47-497c-b4c1-c37eafbd7fbe	2024
fd7db46b-a2dd-4b96-8c69-e202b8fb3c16	Jaclin Alcavella	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	d005d74b-fe75-4d9d-8631-865186a74dbb	2024
f78c4b9f-e6d9-42c2-a614-f77c5800a076	Syalaisha Andini Putriansyah	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	d005d74b-fe75-4d9d-8631-865186a74dbb	2024
303acbb4-3b74-4d2c-bef8-5d0a59416fec	Rafly Prabu Darmawan	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	d005d74b-fe75-4d9d-8631-865186a74dbb	2024
3cca2989-31d3-4902-b560-54869bd9e949	Tri Murniya Ningsih	4496ce0b-1054-4cb0-b127-26488eaec15c	kabaleg	https://www.instagram.com/trimurniaa_	 https://www.linkedin.com/in/tri-murniya-ningsih?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app	live your own life	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
630633ec-6373-4331-9de5-4f2defa62046	Annisa Cahyani Surya	4496ce0b-1054-4cb0-b127-26488eaec15c	Sekretaris	https://www.instagram.com/annisacahyanisurya?igsh=eDZvYzc3eWczcnN6	\N	"grow up to learn"	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
a0c3c6e2-6cc2-495c-a660-7bde6264fd0a	Wulan Sabina 	4496ce0b-1054-4cb0-b127-26488eaec15c	bendahara	https://www.instagram.com/wlsbn0	https://www.linkedin.com/in/wulan-sabina-490579217?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app	"sabar"	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
c7f63e6f-fb82-4420-9701-214bd897710b	Eggi satria	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/_egistr	https://www.linkedlink.com/eggisatria23	Jalanin Aja duluu yakan	https://res.cloudinary.com/diqabuwwk/image/upload/v1724859537/WISATA/file_osgidh.jpg	241460d0-b779-47a5-b243-cd27a253a9a4	2024
7769684d-08c1-4e17-953d-44012dab4b39	Aditya Rahman	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/rahm_adityaa?igsh=NDJiZGFzcGFkdW4x	.	Selalu suka menjadi angin	https://res.cloudinary.com/diqabuwwk/image/upload/v1725021635/WISATA/file_joawfy.jpg	241460d0-b779-47a5-b243-cd27a253a9a4	2024
2849c955-0a73-47db-a0e1-146fb1421475	Happy Syahrul Ramadhan 	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/sudo.syahrulramadhannn/	https://www.linkedin.com/in/syahrulramadhan03/	This too shall pass	https://res.cloudinary.com/diqabuwwk/image/upload/v1724516560/WISATA/file_ccrqba.jpg	241460d0-b779-47a5-b243-cd27a253a9a4	2024
d2614ff1-a7ab-40cf-83e1-f4fb6ca5d1bd	Febiya Jomy Pratiwi	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/pratiwifebiya/	 https://www.linkedin.com/in/febiya-jomy-pratiwi-b05654278?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app	 fearless say yes , we don't dress to impress	https://res.cloudinary.com/diqabuwwk/image/upload/v1724980224/WISATA/file_llmq08.jpg	241460d0-b779-47a5-b243-cd27a253a9a4	2024
3e459045-3ce8-4608-976f-03799cede4d6	Randa Andriana Putra	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/randaandriana_	https://www.linkedin.com/in/randa-andriana-putra	Santai tapi tidak lalai	https://res.cloudinary.com/diqabuwwk/image/upload/v1725034514/WISATA/file_yuiycq.jpg	241460d0-b779-47a5-b243-cd27a253a9a4	2024
00325345-060f-49ed-a646-563c58e3f5aa	Kemas Veriandra Ramadhan 	539d019c-ddae-47f5-904e-d655f2267451	anggota	https://www.instagram.com/kemasverii?igsh=aXZxbGl2aDhhM2I1		New Semester New Me	https://res.cloudinary.com/diqabuwwk/image/upload/v1725096776/WISATA/file_tjon7w.jpg	17712a43-9a47-497c-b4c1-c37eafbd7fbe	2024
190f5eba-1b04-453a-bceb-c599e4168183	Anisa Dini Amalia 	4496ce0b-1054-4cb0-b127-26488eaec15c	kamis	https://www.instagram.com/anisadini10?igsh=MTFyMmt2bWp3aDB4ZA==	\N	 " اَللَّهُمَّ صَلِّ عَلٰى سَيِّدِنَا مُحَمَّدٍ وَعَلٰى آلِ سَيِّدِنَا مُحَمَّدٍ "	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	270887b1-07a2-4a7e-9211-28b872ec57d0	2024
24e0e28c-e552-4d98-9471-129e66f3c25b	Renisha Putri Giani	4496ce0b-1054-4cb0-b127-26488eaec15c	anggota	https://www.instagram.com/fleurnsh?igsh=MW95NTM0OTl6MWhneQ==	\N	"This too shall pass"	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	270887b1-07a2-4a7e-9211-28b872ec57d0	2024
1f533ebb-2fe6-452a-ab17-498f4d95691e	Anisa Fitriyani 	4496ce0b-1054-4cb0-b127-26488eaec15c	anggota	https://www.instagram.com/ansftynn_	\N	be happy for u growth	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	270887b1-07a2-4a7e-9211-28b872ec57d0	2024
ff3497c2-a336-4359-b3b7-63f857499e23	Feryadi Yulius 	4496ce0b-1054-4cb0-b127-26488eaec15c	anggota	https://www.instagram.com/fer_yulius	https://id.linkedin.com/in/feryadi-yulius	"Valar Morghulis"	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	270887b1-07a2-4a7e-9211-28b872ec57d0	2024
abe69a52-21b8-4a38-83e5-b2aeeee9dd00	Claudhea Angeliani	4496ce0b-1054-4cb0-b127-26488eaec15c	kamis	https://www.instagram.com/dylebee	 https://www.linkedin.com/in/claudhea-angeliani-8050822b6?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app	rushing or rushed	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	b9c6aed0-a234-4d63-afd3-438218d52f43	2024
2a3d9cd6-7eba-4ab9-a3bf-f84a1dd563b3	 Mirzan Yusuf Rabbani	4496ce0b-1054-4cb0-b127-26488eaec15c	anggota	https://www.instagram.com/myrrinn	\N	"vox populi, vox dei"	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	b9c6aed0-a234-4d63-afd3-438218d52f43	2024
05b42a48-ecd0-4c92-887b-c420f66ae195	Dhea Amelia Putri	4496ce0b-1054-4cb0-b127-26488eaec15c	anggota	https://www.instagram.com/_.dheamelia?igsh=aGhwa3NkYWV5c2J3	\N	kalo orang ngiri, kita nganan aja	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	b9c6aed0-a234-4d63-afd3-438218d52f43	2024
07b8f253-b84a-4136-89f6-840d8ca02d5a	Muhammad Fahrul Aditya 	4496ce0b-1054-4cb0-b127-26488eaec15c	kamis	https://www.instagram.com/fhrul.pdf?igsh=Z3VwN3FudGVxbmlr	https://www.linkedin.com/in/muhammad-fahrul-aditya-134890220?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app	L'œuvre d'art, c'est une idée qu'on exagère.”	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	c15939f7-d77c-4763-9a58-2822c83b6f57	2024
a16d89c2-09ad-4fed-acdc-cb03de188759	Jeremia Susanto 	4496ce0b-1054-4cb0-b127-26488eaec15c	anggota	https://www.instagram.com/jeremia_s_	\N	Laba-laba Sunda	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	c15939f7-d77c-4763-9a58-2822c83b6f57	2024
182b1c09-91e1-48f9-bcbb-ecef14af1194	berliana enda putri	4496ce0b-1054-4cb0-b127-26488eaec15c	anggota	https://www.instagram.com/berlyyanda?igsh=azFra3hwcmZyMDN4	\N	banyak duit, hidup foya"	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	c15939f7-d77c-4763-9a58-2822c83b6f57	2024
53218f77-2a60-48ad-afc5-1805d46a892f	Ahmad Sahidin Akbar	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/sahid22__?igsh=MWNnZnUxYXNzN252bg==	https://www.linkedin.com/in/ahmad-sahidin-akbar?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app	Perubahan tidak datang dari kaki yang diam	https://res.cloudinary.com/diqabuwwk/image/upload/v1724811611/WISATA/file_kthwve.jpg	fa03c74d-41ab-4824-83f3-0c3c50508500	2024
64fd7c54-4306-4bda-97a4-d2cd797f2a65	Tessa Kania Sagala	d5b8df06-2409-463c-b3d2-b1f44426704b	anggota	https://www.instagram.com/tesakanias	\N	Think before you act	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	33998c2d-588f-4b30-8e3e-d841edca427a	2024
dbfd606e-85d7-405f-b5d0-15a240092a2c	Muhammad Regi Abdi Putra Amanta	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/mregiiii_?igsh=MWhqMWI5YWU3ZW1qcA==	https://www.linkedin.com/in/muhammad-regi-abdi-putra-amanta?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app	just do my best	https://res.cloudinary.com/diqabuwwk/image/upload/v1724812736/WISATA/file_bhyoky.jpg	fa03c74d-41ab-4824-83f3-0c3c50508500	2024
05c87408-c143-408f-bc47-102881370fcc	Ahmad Rizqi 	d5b8df06-2409-463c-b3d2-b1f44426704b	anggota	https://www.instagram.com/ahmad.riz45	\N	Jalani aja dulu	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	33998c2d-588f-4b30-8e3e-d841edca427a	2024
b5fb87c6-2966-46e8-affb-ce564c111d6d	Danang Hilal Kurniawan 	d5b8df06-2409-463c-b3d2-b1f44426704b	anggota	https://www.instagram.com/dananghk_	https://www.linkedin.com/in/dananghilalkurniawan/	Look, Personality, and Money 	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	33998c2d-588f-4b30-8e3e-d841edca427a	2024
080209f3-d805-4fb9-911f-675483f8ce4c	Farrel Julio Akbar	d5b8df06-2409-463c-b3d2-b1f44426704b	anggota	https://www.instagram.com/farrel__julio/	https://www.linkedin.com/in/farrel-julio-427143288/	“Ex Favilla,Nos Resurgemus“	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	33998c2d-588f-4b30-8e3e-d841edca427a	2024
0d0648a0-942c-4e06-9174-8972abb2b2bc	Elia Meylani Simanjuntak	d5b8df06-2409-463c-b3d2-b1f44426704b	anggota	https://www.instagram.com/meylanielia	https://www.linkedin.com/in/elia-meylani/	jalanin aja dlu	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	14d5c446-5283-4967-8c27-8165ee07761c	2024
c35f6603-3d3c-4381-a544-72f2c059fd68	Dhafin Razaqa Luthfi	d5b8df06-2409-463c-b3d2-b1f44426704b	anggota	https://www.instagram.com/dhafinrzqa13	\N	Kesuksesan yang besar dimulai dari langkah yang kecil	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	14d5c446-5283-4967-8c27-8165ee07761c	2024
7f5ef230-739f-4aa9-9f33-328ff1d368d0	Alvia Asrinda Br.Gintng	d5b8df06-2409-463c-b3d2-b1f44426704b	anggota	\N	\N	Jangan bergantung pada orang lain	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	14d5c446-5283-4967-8c27-8165ee07761c	2024
11427be9-3ea8-4434-8841-aa5d485b8537	Ericson Chandra Sihombing	539d019c-ddae-47f5-904e-d655f2267451	kadep	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
7c110ed7-d746-4a40-a895-b15b6ab9432f	Elisabeth Claudia Simanjuntak	539d019c-ddae-47f5-904e-d655f2267451	Sekretaris	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
737f68f7-96d9-46e0-b732-34187b5bfb15	Nisrina Nur Afifah 	539d019c-ddae-47f5-904e-d655f2267451	kadiv	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	f46fddc8-39e2-4100-80d5-9351d3b6aece	2024
82388b73-a950-4a1b-acdf-9e9356501cf9	Deyvan Loxefal	539d019c-ddae-47f5-904e-d655f2267451	kadiv	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	17712a43-9a47-497c-b4c1-c37eafbd7fbe	2024
efb98786-3d8f-494f-93fd-b7097c6376d0	M. Farhan Athaulloh	539d019c-ddae-47f5-904e-d655f2267451	kadiv	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	d005d74b-fe75-4d9d-8631-865186a74dbb	2024
7c4b4dfb-08f7-45cc-9a09-7ab90c032bd2	Cintya Bella	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	ef1725bd-e842-4ca5-a5de-adcef39fe162	2024
bb16ff56-b0b6-44f7-a711-28af7bacf2d9	Eka Fidiya Putri	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	ef1725bd-e842-4ca5-a5de-adcef39fe162	2024
cc3900d6-c04b-43b5-9488-5e0d88845c4e	Najla Juwairia	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	ef1725bd-e842-4ca5-a5de-adcef39fe162	2024
1295c029-70be-4625-a7d6-b996a45da175	Anissa Luthfi Alifia	eef7dd19-8737-48a6-9a76-b21e22c900f7	Senator	http://instagram.com/anissaluthfi_	http://linkedin.com/in/anissa-luthfi-alifia	Segala hal yang nyata dan kau inginkan tetapi belum dapat kau raih adalah fiksi, tetapi semua mimpi yang fiksi dan kau usahakan adalah nyata. - Fredrik Ornata	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
1398ee7a-d006-4f6d-aa1f-23b8182b37b4	Rian Bintang Wijaya	eef7dd19-8737-48a6-9a76-b21e22c900f7	anggota	http://instagram.com/bintangtwinkle	http://linkedin.com/in/anissa-luthfi-alifia	"Do small things with great love" - mother teresa	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
b2e56fc9-6291-4c7e-8bf5-fa5be3b0d9a1	Annisa Novantika	6a617094-d1f5-4838-843f-5790976ebd91	Sekretaris	https://www.instagram.com/anovavona	https://www.linkedin.com/in/annisa-novantika/	Balas dendam terbaik adalah menjadikan dirimu lebih baik	https://res.cloudinary.com/diqabuwwk/image/upload/v1724935600/WISATA/file_xughyf.jpg	\N	2024
765fa323-0eea-44a7-872a-fa170c27e728	Meliza Wulandari	d7b8375a-988a-4d96-be68-b68885c93486	Sekretaris	https://www.instagram.com/wulandarimeliza	https://www.linkedin.com/in/meliza-wulandari/	Kalo kamu punya impian, tingkatin usahanya bukan turunin standarnya	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
fa074757-fcd1-4af0-8470-301968ed8545	Putri Maulida Chairani	d7b8375a-988a-4d96-be68-b68885c93486	Sekretaris	https://www.instagram.com/ptrimaulidaaa_	https://www.linkedin.com/in/putri-maulida-chairani	Don't rush yet don't stop!	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
10326336-5dbc-41e3-b580-e75f237b565c	Nadilla Andhara Putri	d7b8375a-988a-4d96-be68-b68885c93486	bendahara	https://www.instagram.com/nadillaandr26?igsh=MWNkazJxejRlY2Z5dg==	.	Jadikan kesalahan sebagai guru, bukan musuh	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
9761311a-2b8d-405b-b770-9b91b070b7aa	Vita Anggraini 	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/vita.annn/	-	 	https://res.cloudinary.com/diqabuwwk/image/upload/v1725032562/WISATA/file_p80nkl.jpg	241460d0-b779-47a5-b243-cd27a253a9a4	2024
045ac149-4995-4469-99d4-3d97e977064e	Rafi Fadhlillah	6a617094-d1f5-4838-843f-5790976ebd91	kadep	https://www.instagram.com/rafadhlillahh13?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==	https://www.linkedin.com/in/rafi-fadhlillah-049492204	Kalau Ada Niat, Pasti Ada Jalan	https://res.cloudinary.com/diqabuwwk/image/upload/v1725033280/WISATA/file_yuhq58.jpg	\N	2024
296a81f1-5282-4bd4-9e40-0673f01cff95	Abdurrahman Al-atsary	6a617094-d1f5-4838-843f-5790976ebd91	kadiv	https://www.instagram.com/rahmn_abdr/	https://www.linkedin.com/in/abdurrahman-al-atsary/	Alon alon asal kelakon...	https://res.cloudinary.com/diqabuwwk/image/upload/v1725116898/WISATA/file_xszjgw.jpg	241460d0-b779-47a5-b243-cd27a253a9a4	2024
9a28e72d-7ffe-4c24-af4e-1dfd9403bae0	Patricia Leondrea Diajeng Putri 	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	ef1725bd-e842-4ca5-a5de-adcef39fe162	2024
ff8ae60a-0ae9-4e8f-9217-7e7b29ef8833	Rahma Neliyana	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	ef1725bd-e842-4ca5-a5de-adcef39fe162	2024
9f9a2148-fc63-42f3-a1c2-4bed3f086b11	Try Yani Rizki Nur Rohmah	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	ef1725bd-e842-4ca5-a5de-adcef39fe162	2024
6b03fbf0-d433-48b0-a314-63cdc48f507c	Dwi Ratna Anggraeni 	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	d2666b7b-eff6-4851-b14f-70ab240b203f	2024
fd816b0c-e56c-4ab3-944e-8ae770339477	Nasywa Nur Afifah	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	d2666b7b-eff6-4851-b14f-70ab240b203f	2024
e49e5bae-da7f-4de2-8aea-fbc982456a2b	Priska Silvia Ferantiana	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	d2666b7b-eff6-4851-b14f-70ab240b203f	2024
8e8c6106-8db7-4f9b-874b-a3ccddaa5abc	Abit Ahmad Oktarian	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	cb48c1a2-3a43-41b4-be39-8e6ed719d0c0	2024
95b8dea5-9514-4444-bec7-22add183052c	Akmal Faiz Abdillah	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	cb48c1a2-3a43-41b4-be39-8e6ed719d0c0	2024
1c8d123f-5f6f-41c0-a994-92f8c6afe3b2	Hermawan Manurung	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	cb48c1a2-3a43-41b4-be39-8e6ed719d0c0	2024
9a096c44-6c3d-4289-bee0-90d69cb69637	Khusnun Nisa	71b84840-9957-4875-8cac-3711a661ca60	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	cb48c1a2-3a43-41b4-be39-8e6ed719d0c0	2024
bf54de66-b2d9-4f98-b7e8-e76dd6a0a4f5	Natanael Oktavianus Partahan Sihombing	6a617094-d1f5-4838-843f-5790976ebd91	kadiv	https://www.instagram.com/natanaelokt?igsh=d2Y1Yjk5M3F2bWE1	\N	Jangan bersaing dengan sesamamu, bersainglah dengan dirimu yang dulu	https://res.cloudinary.com/diqabuwwk/image/upload/v1724858829/WISATA/file_j4xj27.jpg	a2172ddb-9392-4df1-89db-9989350e962e	2024
fc0e7ce4-661e-428e-8971-26b543995e25	Fadhil Fitra Wijaya	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/fadhilfwee/	\N	Percayakan hidup ini kepada yang maha kuasa	https://res.cloudinary.com/diqabuwwk/image/upload/v1724860358/WISATA/file_jr8kms.jpg	fa03c74d-41ab-4824-83f3-0c3c50508500	2024
38f77ae1-3ee5-4a43-87e8-441e1f8fcc31	Mujadid Choirus Surya	6a617094-d1f5-4838-843f-5790976ebd91	kadiv	https://www.instagram.com/mujadidchrss/	https://www.linkedin.com/in/mujadidchoirussurya	Dan bersabarlah kamu, sesungguhnya janji Allah adalah benar	https://res.cloudinary.com/diqabuwwk/image/upload/v1724861660/WISATA/file_kueffc.jpg	fa03c74d-41ab-4824-83f3-0c3c50508500	2024
bf25611a-2a64-4531-8060-6cb3dbeccf92	Gymnastiar Al Khoarizmy	71b84840-9957-4875-8cac-3711a661ca60	anggota				https://res.cloudinary.com/diqabuwwk/image/upload/v1725167525/WISATA/file_ew5aaw.jpg	d2666b7b-eff6-4851-b14f-70ab240b203f	2024
3d9cc517-253b-4cd4-8cdd-69b61cf4b94e	Marleta Cornelia Leander	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/marletacornelia/	-	bawa dalam doa	https://res.cloudinary.com/diqabuwwk/image/upload/v1724862011/WISATA/file_qw3dcz.jpg	a2172ddb-9392-4df1-89db-9989350e962e	2024
af38b31a-5dd7-4281-ba1a-3433bf33c396	Deva Anjani Khayyuninafsyah	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/anjaniiidev?igsh=YXI4b2hpNmFocmZz	-	Be the best version of yourself.	https://res.cloudinary.com/diqabuwwk/image/upload/v1724862044/WISATA/file_sztqv6.jpg	a2172ddb-9392-4df1-89db-9989350e962e	2024
276febe3-47b7-40e2-8aa8-75d169cbadea	Dinda Nababan	6a617094-d1f5-4838-843f-5790976ebd91	anggota	http://instagram.com/dindanababan_	-	Everyone has a happy ending. If you are not happy, it's not the end	https://res.cloudinary.com/diqabuwwk/image/upload/v1724862068/WISATA/file_byaqqb.jpg	a2172ddb-9392-4df1-89db-9989350e962e	2024
a16757b6-56d2-46fc-b978-cfd30abf750e	Syadza Puspadari Azhar	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/puspadrr?igsh=MXdjYXRzMGJhMmp3aA==	-	Take it easy	https://res.cloudinary.com/diqabuwwk/image/upload/v1724862094/WISATA/file_n2ncfw.jpg	a2172ddb-9392-4df1-89db-9989350e962e	2024
ba2ed020-6633-4c5f-ac52-0ba4ae2aad2b	Syalaisha Andina Putriansyah	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/dkselsd_31/	-	Create your own sunshine	https://res.cloudinary.com/diqabuwwk/image/upload/v1724862142/WISATA/file_kjqupo.jpg	fa03c74d-41ab-4824-83f3-0c3c50508500	2024
c6f6dc85-48c7-4e6d-9f4c-7358fc85505f	Rut Junita Sari Siburian	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/junitaa_0406?igsh=b3hxN2VpNGNza2w4	-	Life without prayer is like a ship without a compass, keep praying.	https://res.cloudinary.com/diqabuwwk/image/upload/v1724862183/WISATA/file_qiqijg.jpg	a2172ddb-9392-4df1-89db-9989350e962e	2024
4e45cd5d-60df-418f-8611-372ae0606726	Kharisma Gumilang	d7b8375a-988a-4d96-be68-b68885c93486	kahim	https://www.instagram.com/gumilangkharisma	https://www.linkedin.com/in/kharisma-gumilang/	⁠Every 1000 problem there are 10001 solutions	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
e73ed237-c8b7-444e-bfa2-a763afb36c3f	Pandra Insani Putra Azwar	d7b8375a-988a-4d96-be68-b68885c93486	sekjen	https://www.instagram.com/pndrinsni27	https://www.linkedin.com/in/pandra-insani-putra-azwar-56a757253?trk=contact-info	Ikhtiar,doa & tawakal	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
4f9c9386-281e-4217-9d1e-7b77ce8d8d54	Natasya Ega Lina	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/nateee__15/?utm_source=qr&r=nametag	\N	print("iso ra iso halsu isseo")	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	769f1c5d-8dde-4b20-8ca4-383a4277597e	2024
67032a5f-bb0a-47e6-a271-f13c96b94af5	Esteria Rohanauli Sidauruk	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/esteriars?igsh=ZjI0dW0xZjNoNjdq	\N	And if you never bleed, you're never grow	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	769f1c5d-8dde-4b20-8ca4-383a4277597e	2024
9c21fc2a-8bfd-4065-9ef7-f6b1e742b695	Yohana Manik	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/yo_anamnk	\N	motivasi tanpa aksi hanyalah halusinasi 	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	769f1c5d-8dde-4b20-8ca4-383a4277597e	2024
acd1ffdd-b966-414d-a455-9cde4d03476b	Novelia Adinda	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/nvliaadinda	\N	hold on to memories, they will hold on to you	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	769f1c5d-8dde-4b20-8ca4-383a4277597e	2024
cc1ea2e5-6c68-45b9-a7cf-40f4ef5f1238	Bastian Heskia Silaban	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/bastiansilaban_	\N	being too ambitious will kill your identity	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	769f1c5d-8dde-4b20-8ca4-383a4277597e	2024
03b180ca-f21e-4c1c-9ee5-ecc5fa53e114	Dea Mutia Risani	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/deaa.rsn	\N	do what u love, love what u do	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	769f1c5d-8dde-4b20-8ca4-383a4277597e	2024
be858b03-ce8c-4973-8951-02b404cd8d50	Izza Lutfia	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/izzalutfiaa	https://www.linkedin.com/in/izzalutfiaa	Jikal gagal, langsung coba coba coba lagi sampai berhasil	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	8a3528f4-d398-4d25-8bed-51ad97e7510c	2024
832ad555-89f7-477b-aedb-88371a6f56c2	Arafi Ramadhan Maulana	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/arafiramadhanmaulana	https://www.linkedin.com/in/arafiramadhanmaulana	dicoba kok enak	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	8a3528f4-d398-4d25-8bed-51ad97e7510c	2024
6cf5e56d-b082-4fde-ac22-3e96162bfe79	Raid Muhammad Naufal	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/rayths_	https://www.linkedin.com/in/raidmnaufal	enak banget yaa	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	8a3528f4-d398-4d25-8bed-51ad97e7510c	2024
61d8f498-99ba-4545-a6d0-5f0fb7ae8bf0	Tria Yunanni	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/tria_y062	https://www.linkedin.com/in/tria-yunanni-78574a2b3?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app	bisaaa	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	8a3528f4-d398-4d25-8bed-51ad97e7510c	2024
7548f64f-ae8a-4b54-81a1-7e8d1453c331	Chalifia Wananda 	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/chlfawww 	https://www.linkedin.com/in/chalifia-wananda-887b7928b	life goes on ceunahh💨	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	8a3528f4-d398-4d25-8bed-51ad97e7510c	2024
96776577-f459-4df7-b304-4e6ecbd3233e	Asa Do'a Uyi	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/u_yippy	https://id.linkedin.com/in/asa-do-a-uyi-445310256	Kecil Disuka, Muda Terkenal, Tua Kaya Raya, Mati Masuk Surga	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	8a3528f4-d398-4d25-8bed-51ad97e7510c	2024
0a80f89f-c5dc-4dd6-96ec-91e1abef75c4	Nazwa Nabilla	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	kadiv	https://www.instagram.com/nazwanbilla	https://www.linkedin.com/in/nazwa-nabilla-5a16822ba/	apa yaa	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	769f1c5d-8dde-4b20-8ca4-383a4277597e	2024
cbdb56c8-3716-47fd-ba88-2b491191911c	Ramadhita Atifa Hendri	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	Sekretaris	https://www.instagram.com/ramadhitatifa	\N	enjoy every process	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
dfbc40ca-cce9-4678-b59c-903bf31b7ee8	Yogy Sae Tama	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	kadep	https://www.instagram.com/yogyyyyyyy	\N	Sabar	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
3b394909-078f-4f32-a3de-2803178202ed	Rizki Adrian Bennovry	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	kadiv	https://www.instagram.com/rzkdrnnn	https://www.linkedin.com/in/rizkiadrianbennovry	pengen jadi kaesang	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	8a3528f4-d398-4d25-8bed-51ad97e7510c	2024
400cadfa-e4fb-4eb8-8872-7db5ef42e161	Ratu Keisha Jasmine Deanova 	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	769f1c5d-8dde-4b20-8ca4-383a4277597e	2024
3b590a41-66f5-40fc-924d-040cf8fabe60	Khaalishah Zuhrah Alyaa Vanefi	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/alyaavanefi	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	8a3528f4-d398-4d25-8bed-51ad97e7510c	2024
1a3042a3-84e7-4ea3-a86d-8ad5d72d708b	Hartiti Fadilah	d7b8375a-988a-4d96-be68-b68885c93486	bendahara	https://www.instagram.com/hartitifadilah	\N	Ar-Ra'd : 11	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
9a201c50-4dd0-41dd-a80f-c8f0ee5d25d9	Dimas Rizky Ramadhani 	829df915-e111-4992-9286-4e00f7fd159d	kadep	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
adef9045-cb47-4d60-b247-7332e10ef158	Catherine Firdhasari Maulina Sinaga	829df915-e111-4992-9286-4e00f7fd159d	Sekretaris	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
dfc85155-569a-4c9f-8e35-3a0b472b1281	Ari Sigit 	829df915-e111-4992-9286-4e00f7fd159d	kadiv				https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	09462714-d91f-4267-b520-84bab83ae0de	2024
5b88632b-1a5a-4730-90b2-e480836a18f0	Azizah Kusumah Putri 	829df915-e111-4992-9286-4e00f7fd159d	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	09462714-d91f-4267-b520-84bab83ae0de	2024
35a4d8a6-e9fd-4f6a-908b-b2488ea159bf	Dearni Monica Br Manik 	829df915-e111-4992-9286-4e00f7fd159d	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	09462714-d91f-4267-b520-84bab83ae0de	2024
b3477b52-265e-4ab7-abee-5036e3c7b8b4	Meira Listyaningrum 	829df915-e111-4992-9286-4e00f7fd159d	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	09462714-d91f-4267-b520-84bab83ae0de	2024
5a316107-f56e-4417-a712-bd31e5f68d8e	Renta Siahaan	829df915-e111-4992-9286-4e00f7fd159d	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	09462714-d91f-4267-b520-84bab83ae0de	2024
27092f1c-1044-4afe-b7d0-14262ee822da	Rendi Alexander Hutagalung	829df915-e111-4992-9286-4e00f7fd159d	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	09462714-d91f-4267-b520-84bab83ae0de	2024
a4d408c0-4585-407c-9e40-85a637d1af1a	Rani Puspita sari 	829df915-e111-4992-9286-4e00f7fd159d	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	b1cba988-19fc-41da-bebf-151b236f2eec	2024
8f94a350-3dba-4084-838f-ea7a6fb3e2fd	Rendra Eka Prayoga 	829df915-e111-4992-9286-4e00f7fd159d	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	b1cba988-19fc-41da-bebf-151b236f2eec	2024
d9ffcefe-ca5b-4b1f-8ebd-49ba33d09038	Salwa Farhanatussaidah	829df915-e111-4992-9286-4e00f7fd159d	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	b1cba988-19fc-41da-bebf-151b236f2eec	2024
86303faf-4787-4c5f-b9ab-18e3a72a14ac	Akbar Resdika	829df915-e111-4992-9286-4e00f7fd159d	kadiv				https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	b1cba988-19fc-41da-bebf-151b236f2eec	2024
5f8d7bfb-0f35-4b5a-946d-6734bde6ff01	Wahyudiyanto	71b84840-9957-4875-8cac-3711a661ca60	kadep	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
c2cd644f-9368-40ac-9f68-efd6074f4f30	Elok Fiola	71b84840-9957-4875-8cac-3711a661ca60	Sekretaris	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
d8b631b8-6a69-4195-96a0-40ef1b038763	Muhammad Kaisar Firdaus	71b84840-9957-4875-8cac-3711a661ca60	kadiv	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	d2666b7b-eff6-4851-b14f-70ab240b203f	2024
bc44e24a-0f1c-45ad-b85f-59a8f8c826ba	Arsyiah Azahra	71b84840-9957-4875-8cac-3711a661ca60	kadiv	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	ef1725bd-e842-4ca5-a5de-adcef39fe162	2024
df5818f3-35eb-4853-ad87-3e0e6e669b60	Muhammad Arsal Ranjana Utama	71b84840-9957-4875-8cac-3711a661ca60	kadiv	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	cb48c1a2-3a43-41b4-be39-8e6ed719d0c0	2024
23f9caaf-b87f-4c35-a089-9c27a5484f5f	Andrian Agustinus Lumban Gaol	d5b8df06-2409-463c-b3d2-b1f44426704b	kadep	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
a413a032-956e-4173-93c8-8ab64ed94789	Adisty Syawaida Ariyanto	d5b8df06-2409-463c-b3d2-b1f44426704b	Sekretaris	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	\N	2024
e2540709-649f-4d0f-84fc-6c5ea8834774	Nabila Azhari	d5b8df06-2409-463c-b3d2-b1f44426704b	kadiv				https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	33998c2d-588f-4b30-8e3e-d841edca427a	2024
fc8c57f5-b241-4074-af3f-b0167b66370f	Nabilah Andika Fitriati	d5b8df06-2409-463c-b3d2-b1f44426704b	kadiv	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	14d5c446-5283-4967-8c27-8165ee07761c	2024
8292cc5a-5ca0-4e53-90ba-6724ae541739	Anwar Muslim	6a617094-d1f5-4838-843f-5790976ebd91	anggota	https://www.instagram.com/here.am.ai?igsh=Y2plMXZheG1odXZp	-	One day, my grass will be the greenest	https://res.cloudinary.com/diqabuwwk/image/upload/v1725103561/WISATA/file_bugdow.jpg	a2172ddb-9392-4df1-89db-9989350e962e	2024
1bdf56e7-5b49-459c-b16e-55242023bbb2	Irvan Alfaritzi	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/alfaritziirvan	https://www.linkedin.com/in/irvan-alfaritzi-a0463a309?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app	Hidup adalah perjalanan, jadi nikmati setiap langkahnya	https://res.cloudinary.com/diqabuwwk/image/upload/v1725628267/WISATA/file_efkqax.jpg	8a3528f4-d398-4d25-8bed-51ad97e7510c	2024
883e6dc4-96c8-4360-a9aa-87a045204552	Tobias David Manogari	0caaa47f-3c45-4f1f-91d2-f324f50a0deb	anggota	https://www.instagram.com/tobiassiagian/	\N	Hidup harus berani bertanggung jawab!!!	https://res.cloudinary.com/diqabuwwk/image/upload/v1725628277/WISATA/file_gz9krx.jpg	769f1c5d-8dde-4b20-8ca4-383a4277597e	2023
a38bc273-0fdc-4e23-9ba7-ede4792f2bd8	Vanessa Olivia Rose	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	17712a43-9a47-497c-b4c1-c37eafbd7fbe	2024
6003e0ab-9f0f-4453-a826-4afda4868c3e	Ibnu Farhan Al-Ghifari	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	17712a43-9a47-497c-b4c1-c37eafbd7fbe	2024
1763e3cd-b261-4a73-81f0-34b447e7ed92	Leonard Andreas Napitupulu	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	17712a43-9a47-497c-b4c1-c37eafbd7fbe	2024
c05a938d-5d56-49b8-af4f-028c11656650	Gede Moana	539d019c-ddae-47f5-904e-d655f2267451	anggota	\N	\N	\N	https://res.cloudinary.com/diqabuwwk/image/upload/v1722842916/WISATA/default-profile-picture_e8owr2.png	d005d74b-fe75-4d9d-8631-865186a74dbb	2024
\.


--
-- Data for Name: merchants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.merchants (id, title, description, thumbnail, category_id, price, link_whatsapp, "createdAt", "updatedAt") FROM stdin;
484a6435-7959-4dd4-907b-1b56b4298343	Gantungan Kunci Anak Belwiss	Gantungan Kunci Kece 	https://res.cloudinary.com/diqabuwwk/image/upload/v1724850941/WISATA/file_gf2k6p.jpg	892a9c73-3395-49aa-ab70-65b6b18cd441	10000	wa.me/081220440019	2024-08-28 13:15:42.676	2024-08-28 13:15:42.676
\.


--
-- Data for Name: portofolios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.portofolios (id, title, description, thumbnail, category_id, link_project, "createdAt", "updatedAt") FROM stdin;
62974bc7-85f6-4733-8bac-f3f9517991a0	WISATA	Website Resmi Himpunan Mahasiswa Sains Data ITERA. yang dibangun mengunakan stack nextjs,Express,Postgresql,Node dan kasih sayang	https://res.cloudinary.com/diqabuwwk/image/upload/v1724678653/WISATA/file_p0xrph.png	01786e8e-0409-4386-a55a-95a5889a3d8c	https://github.com/snrhmsd	2024-08-26 13:24:18.375	2024-08-30 18:14:59.068
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refresh_tokens (token, user_id, expires) FROM stdin;
2e5a89ac-af4f-4deb-996a-c1253a9c6d79	116729146132809119225	2024-08-25 09:41:32.521
aa333232-9e81-4913-a1b9-18ced833d84c	116729146132809119225	2024-08-25 09:59:56.049
290984f8-44bc-4e9d-ac04-fd3bc96f77c7	116729146132809119225	2024-08-25 12:14:16.453
85d0935c-eb01-4398-a297-110088d25e0e	116729146132809119225	2024-08-25 14:58:21.164
7f91c515-b3b1-401e-91db-26c0167ba9b8	116729146132809119225	2024-08-26 07:59:24.482
de7f4012-8753-4038-96fa-2b5b7eb78d1b	115912283964863269287	2024-08-26 08:02:08.188
ecf60191-c0e5-4157-84fb-e3d25ed39786	116729146132809119225	2024-08-26 15:14:27.399
a4971579-8441-4338-8764-7cb18148248b	116729146132809119225	2024-08-31 15:47:32.138
c7c60495-7fc0-47a8-a1c0-43c2d5ed2bac	116729146132809119225	2024-08-31 15:49:59.961
637f9533-d6ec-47da-ae82-15b7c35a5c51	116729146132809119225	2024-08-31 15:51:34.699
897b2278-9f6b-4d15-9f42-ba8ff0a2884d	116729146132809119225	2024-08-31 16:04:12.58
187a1f73-619d-41b2-9ccc-daa1c1a45dec	110859962141543654662	2024-08-31 16:10:38.635
706c8ed1-6ce6-4e85-8446-fd8156fd7a83	110859962141543654662	2024-08-31 16:12:09.973
da35d285-a7f8-4deb-830c-52eca1e1eaf9	110859962141543654662	2024-08-31 16:13:14.009
2a4386fd-8067-4e85-b351-dc27d7a01991	110859962141543654662	2024-08-31 16:14:40.74
5b926e95-a7fa-4670-8931-fb18ae52150d	110859962141543654662	2024-08-31 16:15:59.312
4af11250-fefe-4fc8-b760-698b14384aca	114937957947427800383	2024-08-31 16:35:45.116
68c414da-7a92-45e7-92f7-acefc7ab7739	110859962141543654662	2024-08-31 17:03:16.132
94ca3762-4693-4ba0-a931-af21bfda929c	116729146132809119225	2024-08-31 17:05:05.823
7a56643f-41e3-4a76-aa32-8edd218c4950	7510d9f6-1d2b-40b5-835d-43c45d6f4d6f	2024-09-01 07:58:07.543
8f5aaf35-4c59-4211-b7e4-717d3fa6aa50	775d164a-927d-4b40-b861-109dbd2ed7d4	2024-09-02 13:10:11.542
af818de3-c62b-4e29-8642-5fbfda70fb39	116729146132809119225	2024-09-02 13:10:40.419
e0f9b414-ecd7-4e88-b902-1f882b7d61c6	99e98391-9666-46cf-8ff6-9200e65a7a2e	2024-09-02 14:21:17.372
551f03ea-a80b-436e-bc24-cc85d6ea209a	7510d9f6-1d2b-40b5-835d-43c45d6f4d6f	2024-09-02 14:52:12.145
52b9dd6d-117e-4ad9-9001-cfd89914ca02	f270efee-9d1e-42d1-84f4-ca20a543e13c	2024-09-03 07:40:08.664
08c7fae9-8369-440b-adb3-3467373d810b	dd56d8b9-2aa0-4eef-ae0c-d5e5f46a3fce	2024-09-03 15:55:52.196
1aa4de30-0bcf-4339-9ea7-c21db0ef0324	dd56d8b9-2aa0-4eef-ae0c-d5e5f46a3fce	2024-09-03 15:56:25.068
22d667d4-eb5a-4ca0-a10b-8842b664b80a	dd56d8b9-2aa0-4eef-ae0c-d5e5f46a3fce	2024-09-03 16:15:31.137
11af9586-9fe3-425b-93fd-8306b95a39c1	dd56d8b9-2aa0-4eef-ae0c-d5e5f46a3fce	2024-09-03 16:25:44.534
7f8eeb40-fe04-4270-bc09-8d5dad226f6a	dd56d8b9-2aa0-4eef-ae0c-d5e5f46a3fce	2024-09-04 08:22:43.733
8c2afbd1-face-4c39-8a95-5e63b50509ea	775d164a-927d-4b40-b861-109dbd2ed7d4	2024-09-04 13:34:24.682
d9af9c0e-73a6-4462-ba38-3bd2daa6d274	100638094458607315703	2024-09-04 14:51:57.616
fe6a9872-a16b-4d13-851d-e3ca42cb41f5	99e98391-9666-46cf-8ff6-9200e65a7a2e	2024-09-04 14:52:34.272
ff663c35-8b0a-408c-92c1-406ab1677350	64b37139-68c2-401c-a395-0358c804dbfc	2024-09-04 14:53:33.324
0cb2b314-5ca8-46a9-ae3f-96fce572f253	775d164a-927d-4b40-b861-109dbd2ed7d4	2024-09-05 10:36:16.511
441b051c-e770-466c-82a3-2a9e2b7d42af	110859962141543654662	2024-09-05 12:05:34.367
bfc0658d-6e8d-402c-b446-ec9f9ec9e6cb	110024539460820073768	2024-09-07 13:16:39.991
0245a4ae-9c06-4820-b8b9-38aacbf7895d	112812691065927719027	2024-09-07 14:31:32.066
94e5ae1b-d310-4f1a-9446-077d86d844ad	116729146132809119225	2024-09-07 14:32:32.06
10770427-1395-4972-ad72-912ffa84f6cf	112812691065927719027	2024-09-07 14:49:45.459
eb4f6b5b-a60e-4e5e-abf7-fd5bbf1c5e56	112812691065927719027	2024-09-07 15:10:22.4
8318efa1-6b70-43d8-a4d1-d58283bbdb8f	775d164a-927d-4b40-b861-109dbd2ed7d4	2024-09-07 15:49:53.842
6d5c0a1f-02a7-4687-a677-a44b4ff199fc	116729146132809119225	2024-09-08 01:27:21.133
3a4481ea-b91a-4577-a885-1b7db095407c	107754922367042095415	2024-09-08 03:45:15.211
e63b8704-ae04-4abb-929a-e331b6973e82	101395244589397588529	2024-09-08 05:21:45.151
b2bdf182-0aee-4850-a799-c3e46f99c8f7	115243940961281161653	2024-09-08 07:09:09.077
8ca6a9f5-9419-4ad8-975d-4b9d42ed3609	112812691065927719027	2024-09-08 11:21:13.731
e32a1c3a-a822-4afc-9bf7-b61a8f0bc401	112812691065927719027	2024-09-08 11:21:28.622
97bb138b-bf62-4281-ac8c-3b509cb5138a	101236885004814296600	2024-09-08 11:52:17.173
4a6648e8-48e2-4151-b33a-ac570278f72b	7510d9f6-1d2b-40b5-835d-43c45d6f4d6f	2024-09-09 07:59:18.954
228fe5c4-d910-445c-9a2f-75723fdf1f7e	116729146132809119225	2024-09-09 12:43:00.673
0245e079-814a-40d5-88da-bc9f88960234	114619665158660852918	2024-09-09 13:50:03.618
f54a4a1b-a581-432d-bf8a-90304b8a9ed3	7510d9f6-1d2b-40b5-835d-43c45d6f4d6f	2024-09-10 08:55:32.658
9b8cbd8b-f02e-4375-8609-30a0b83d07be	100863162267068863632	2024-09-13 06:26:51.203
8690002f-c775-4ab5-badf-c1aa4803daba	99e98391-9666-46cf-8ff6-9200e65a7a2e	2024-09-13 13:05:44.032
6d38bb30-a519-4ef2-9b58-ff252d87eb53	106969505251720528766	2024-09-14 01:52:56.714
efb7be58-82e9-4008-baa9-64fbb5ce27fe	99e98391-9666-46cf-8ff6-9200e65a7a2e	2024-09-14 09:41:39.939
892a7def-2eb2-4d85-b825-ee282b4ec34a	116729146132809119225	2024-09-15 14:37:04.677
57a83ec1-d884-43c0-ad12-1915e4380a33	110859962141543654662	2024-09-15 14:37:43.641
910ecbf3-fb8a-44d7-815c-5badf249267e	116729146132809119225	2024-09-19 12:40:24.763
ecd1c3df-a1fe-4145-8b2a-6ba8e84bd4e0	113005640794932138237	2024-09-19 14:34:54.017
b85496ad-4d79-4718-ac3d-f64555569435	107903459425221575814	2024-09-20 10:01:32.595
0042afdb-fa59-469a-88bc-1e70450cbd56	a2e48bec-3b09-427b-84bc-c508eae46853	2024-09-23 08:12:48.628
9a2ce441-7837-418d-af6f-894702fdc2ca	a2e48bec-3b09-427b-84bc-c508eae46853	2024-09-23 08:13:38.552
e7a09748-6066-4062-aa10-1b3f54504858	110859962141543654662	2024-09-29 10:45:51.188
844da088-8ffc-4a7f-adcf-70e52f5c6c3c	111709652522843492303	2024-10-01 10:31:29.576
82ba275b-6377-45c6-9c1c-038eeb211c2e	110859962141543654662	2024-10-01 10:32:40.363
4653e4e3-d1d2-4b39-8bf6-47c27d91019d	111709652522843492303	2024-10-01 13:56:12.449
a7c22fa0-d313-4621-9b6f-58f80a1d3318	111709652522843492303	2024-10-01 13:56:42.737
4012b0c3-4a04-44f9-9d06-c53cdd80883d	116729146132809119225	2024-10-02 00:04:06.066
d7e96a74-4b9a-4735-a41e-a6cca28a86e7	115232367001941130425	2024-10-08 07:10:28.024
dcd0abae-f124-48a6-ac0f-45008134a95d	116729146132809119225	2024-10-08 10:53:08.592
bd0886c8-3d16-4472-abe2-e3b5c08ccff5	116729146132809119225	2024-10-10 11:33:19.396
8e5fdd18-1d92-4584-8163-1e936ac3c7d5	108647192141524679305	2024-10-17 15:01:32.692
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, role, department_id, "createdAt", "updatedAt") FROM stdin;
115912283964863269287	EXSTR	egisatria2310@gmail.com	non-student	\N	2024-08-19 08:02:08.033	2024-08-19 08:02:08.033
dd56d8b9-2aa0-4eef-ae0c-d5e5f46a3fce	annisa	annisa.121450005@student.itera.ac.id	admin	6a617094-d1f5-4838-843f-5790976ebd91	2024-08-24 16:12:36.061	2024-08-24 16:12:36.061
110859962141543654662	HAPPY SYAHRUL RAMADHAN	happy.122450013@student.itera.ac.id	admin	6a617094-d1f5-4838-843f-5790976ebd91	2024-08-24 16:10:38.524	2024-08-24 16:15:48.454
775d164a-927d-4b40-b861-109dbd2ed7d4	rafi 	rafi.121450143@student.itera.ac.id	admin	6a617094-d1f5-4838-843f-5790976ebd91	2024-08-24 16:17:18.637	2024-08-24 16:17:18.637
114937957947427800383	Happy Syahrul Ramadhan	syahrul19112003@gmail.com	non-student	\N	2024-08-24 16:35:45.017	2024-08-24 16:35:45.017
7510d9f6-1d2b-40b5-835d-43c45d6f4d6f	aditya	aditya.122450113@student.itera.ac.id	admin	6a617094-d1f5-4838-843f-5790976ebd91	2024-08-18 10:10:45.564	2024-08-25 07:57:25.335
116729146132809119225	EGGI SATRIA	eggi.122450032@student.itera.ac.id	admin	6a617094-d1f5-4838-843f-5790976ebd91	2024-08-18 09:41:32.334	2024-08-26 12:44:45.213
f270efee-9d1e-42d1-84f4-ca20a543e13c	febiya	febiya.122450074@student.itera.ac.id	admin	6a617094-d1f5-4838-843f-5790976ebd91	2024-08-26 12:49:22.59	2024-08-26 12:49:22.59
64b37139-68c2-401c-a395-0358c804dbfc	vita	vita.122450046@student.itera.ac.id	admin	6a617094-d1f5-4838-843f-5790976ebd91	2024-08-26 12:49:40.206	2024-08-26 12:49:40.206
100638094458607315703	Randa Andriana Putra	andrianaranda2104@gmail.com	non-student	\N	2024-08-28 14:51:57.512	2024-08-28 14:51:57.512
110024539460820073768	Sam Cole	potatoffer@gmail.com	non-student	\N	2024-08-31 13:16:39.876	2024-08-31 13:16:39.876
112812691065927719027	Abdurrahman Al	abdurrahman.121450128@student.itera.ac.id	admin	6a617094-d1f5-4838-843f-5790976ebd91	2024-08-31 14:31:31.959	2024-08-31 14:34:18.091
107754922367042095415	Rendra Eka Prayoga	rendra.122450112@student.itera.ac.id	student	\N	2024-09-01 03:45:15.113	2024-09-01 03:45:15.113
101395244589397588529	12O45O1O5_ Devri Zefanya	devri.120450105@student.itera.ac.id	student	\N	2024-09-01 05:21:45.056	2024-09-01 05:21:45.056
115243940961281161653	Pandra Insani Putra Azwar	pandra.121450137@student.itera.ac.id	student	\N	2024-09-01 07:09:08.97	2024-09-01 07:09:08.97
101236885004814296600	Arsal Utama	muhammad.121450111@student.itera.ac.id	student	\N	2024-09-01 11:52:17.073	2024-09-01 11:52:17.073
114619665158660852918	ASA DO'A UYI	asa.122450005@student.itera.ac.id	student	\N	2024-09-02 13:50:03.506	2024-09-02 13:50:03.506
100863162267068863632	Dimas Rizky Ramadhani_ Sains Data	dimas.121450027@student.itera.ac.id	student	\N	2024-09-06 06:26:51.08	2024-09-06 06:26:51.08
106969505251720528766	Nabila Azhari	nabila.121450029@student.itera.ac.id	student	\N	2024-09-07 01:52:56.587	2024-09-07 01:52:56.587
99e98391-9666-46cf-8ff6-9200e65a7a2e	Randa Andriana Putra	randa.122450083@student.itera.ac.id	admin	6a617094-d1f5-4838-843f-5790976ebd91	2024-08-24 16:17:35.862	2024-09-08 14:29:45.402
113005640794932138237	023_Dharu Cahyoaji Sasongko_Sains Data	dharu.123450023@student.itera.ac.id	student	\N	2024-09-12 14:34:53.897	2024-09-12 14:34:53.897
107903459425221575814	Dea Mutia Risani	dea.122450099@student.itera.ac.id	student	\N	2024-09-13 10:01:32.439	2024-09-13 10:01:32.439
111709652522843492303	Virdio Samuel	diosamuel734@gmail.com	admin	6a617094-d1f5-4838-843f-5790976ebd91	2024-09-24 10:31:29.446	2024-09-24 10:34:33.653
115232367001941130425	037_Labo Napitupulu_Sains Data	labo.123450037@student.itera.ac.id	student	\N	2024-10-01 07:10:27.897	2024-10-01 07:10:27.897
bac11ed2-3c17-49c3-86e3-4d00c432e91b	Sofyan Fauzi Dzaki Arif	sofyan.122450116@student.itera.ac.id	admin	\N	2024-10-01 11:17:17.183	2024-10-01 11:17:17.183
a2e48bec-3b09-427b-84bc-c508eae46853	Abit A	abit.122450042@student.itera.ac.id	admin	71b84840-9957-4875-8cac-3711a661ca60	2024-09-16 08:10:51.165	2024-10-03 11:34:50.393
108647192141524679305	Patricia Leondrea Diajeng Putri	patricia.122450050@student.itera.ac.id	student	\N	2024-10-10 15:01:32.526	2024-10-10 15:01:32.526
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY realtime.messages (id, topic, extension, inserted_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2024-08-18 07:48:57
20211116045059	2024-08-18 07:48:57
20211116050929	2024-08-18 07:48:57
20211116051442	2024-08-18 07:48:57
20211116212300	2024-08-18 07:48:57
20211116213355	2024-08-18 07:48:57
20211116213934	2024-08-18 07:48:57
20211116214523	2024-08-18 07:48:57
20211122062447	2024-08-18 07:48:58
20211124070109	2024-08-18 07:48:58
20211202204204	2024-08-18 07:48:58
20211202204605	2024-08-18 07:48:58
20211210212804	2024-08-18 07:48:58
20211228014915	2024-08-18 07:48:58
20220107221237	2024-08-18 07:48:58
20220228202821	2024-08-18 07:48:58
20220312004840	2024-08-18 07:48:58
20220603231003	2024-08-18 07:48:58
20220603232444	2024-08-18 07:48:58
20220615214548	2024-08-18 07:48:58
20220712093339	2024-08-18 07:48:58
20220908172859	2024-08-18 07:48:58
20220916233421	2024-08-18 07:48:58
20230119133233	2024-08-18 07:48:58
20230128025114	2024-08-18 07:48:58
20230128025212	2024-08-18 07:48:58
20230227211149	2024-08-18 07:48:58
20230228184745	2024-08-18 07:48:58
20230308225145	2024-08-18 07:48:58
20230328144023	2024-08-18 07:48:58
20231018144023	2024-08-18 07:48:58
20231204144023	2024-08-18 07:48:58
20231204144024	2024-08-18 07:48:58
20231204144025	2024-08-18 07:48:58
20240108234812	2024-08-18 07:48:58
20240109165339	2024-08-18 07:48:58
20240227174441	2024-08-18 07:48:58
20240311171622	2024-08-18 07:48:58
20240321100241	2024-08-18 07:48:58
20240401105812	2024-08-18 07:48:58
20240418121054	2024-08-18 07:48:58
20240523004032	2024-08-18 07:48:58
20240618124746	2024-08-18 07:48:58
20240801235015	2024-08-18 07:48:58
20240805133720	2024-08-18 07:48:58
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2024-08-18 07:47:49.046859
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2024-08-18 07:47:49.106447
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2024-08-18 07:47:49.120874
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2024-08-18 07:47:49.201002
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2024-08-18 07:47:49.238451
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2024-08-18 07:47:49.297079
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2024-08-18 07:47:49.353303
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2024-08-18 07:47:49.409305
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2024-08-18 07:47:49.469892
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2024-08-18 07:47:49.489804
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2024-08-18 07:47:49.552856
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2024-08-18 07:47:49.566636
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2024-08-18 07:47:49.621327
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2024-08-18 07:47:49.689013
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2024-08-18 07:47:49.744674
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2024-08-18 07:47:49.825912
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2024-08-18 07:47:49.889802
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2024-08-18 07:47:49.953461
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2024-08-18 07:47:50.009368
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2024-08-18 07:47:50.064524
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2024-08-18 07:47:50.117217
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2024-08-18 07:47:50.176445
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2024-08-18 07:47:50.219123
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2024-08-18 07:47:50.294676
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2024-08-18 07:47:50.308882
25	custom-metadata	67eb93b7e8d401cafcdc97f9ac779e71a79bfe03	2024-08-20 13:34:52.190235
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- Name: key_key_id_seq; Type: SEQUENCE SET; Schema: pgsodium; Owner: supabase_admin
--

SELECT pg_catalog.setval('pgsodium.key_key_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_realtime_admin
--

SELECT pg_catalog.setval('realtime.messages_id_seq', 1, false);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: artikels artikels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artikels
    ADD CONSTRAINT artikels_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: contents contents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contents
    ADD CONSTRAINT contents_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: divisions divisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.divisions
    ADD CONSTRAINT divisions_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: kepengurusan kepengurusan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kepengurusan
    ADD CONSTRAINT kepengurusan_pkey PRIMARY KEY (year);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: merchants merchants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.merchants
    ADD CONSTRAINT merchants_pkey PRIMARY KEY (id);


--
-- Name: portofolios portofolios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portofolios
    ADD CONSTRAINT portofolios_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (token);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: artikels_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "artikels_createdAt_idx" ON public.artikels USING btree ("createdAt");


--
-- Name: artikels_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX artikels_slug_key ON public.artikels USING btree (slug);


--
-- Name: artikels_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX artikels_title_idx ON public.artikels USING btree (title);


--
-- Name: artikels_title_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX artikels_title_key ON public.artikels USING btree (title);


--
-- Name: categories_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX categories_name_key ON public.categories USING btree (name);


--
-- Name: contents_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "contents_createdAt_idx" ON public.contents USING btree ("createdAt");


--
-- Name: contents_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contents_title_idx ON public.contents USING btree (title);


--
-- Name: departments_year_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX departments_year_idx ON public.departments USING btree (year);


--
-- Name: events_author_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_author_id_idx ON public.events USING btree (author_id);


--
-- Name: events_category_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_category_id_idx ON public.events USING btree (category_id);


--
-- Name: events_date_start_date_end_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_date_start_date_end_idx ON public.events USING btree (date_start, date_end);


--
-- Name: events_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_title_idx ON public.events USING btree (title);


--
-- Name: kepengurusan_year_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX kepengurusan_year_key ON public.kepengurusan USING btree (year);


--
-- Name: members_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX members_name_idx ON public.members USING btree (name);


--
-- Name: merchants_category_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX merchants_category_id_idx ON public.merchants USING btree (category_id);


--
-- Name: merchants_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "merchants_createdAt_idx" ON public.merchants USING btree ("createdAt");


--
-- Name: merchants_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX merchants_title_idx ON public.merchants USING btree (title);


--
-- Name: name_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX name_index ON public.departments USING btree (name);


--
-- Name: name_index_categories; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX name_index_categories ON public.categories USING btree (name);


--
-- Name: name_index_division; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX name_index_division ON public.divisions USING btree (name);


--
-- Name: portofolios_category_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX portofolios_category_id_idx ON public.portofolios USING btree (category_id);


--
-- Name: portofolios_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "portofolios_createdAt_idx" ON public.portofolios USING btree ("createdAt");


--
-- Name: portofolios_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX portofolios_title_idx ON public.portofolios USING btree (title);


--
-- Name: refresh_tokens_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX refresh_tokens_token_key ON public.refresh_tokens USING btree (token);


--
-- Name: slug_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX slug_index ON public.artikels USING btree (slug);


--
-- Name: type_index_categories; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX type_index_categories ON public.categories USING btree (type);


--
-- Name: users_department_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_department_id_idx ON public.users USING btree (department_id);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: year_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX year_index ON public.kepengurusan USING btree (year);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING hash (entity);


--
-- Name: messages_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX messages_topic_index ON realtime.messages USING btree (topic);


--
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: artikels artikels_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artikels
    ADD CONSTRAINT artikels_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: artikels artikels_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artikels
    ADD CONSTRAINT artikels_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: departments departments_year_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_year_fkey FOREIGN KEY (year) REFERENCES public.kepengurusan(year) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: divisions divisions_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.divisions
    ADD CONSTRAINT divisions_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: events events_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: events events_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: members members_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: members members_division_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_division_id_fkey FOREIGN KEY (division_id) REFERENCES public.divisions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: merchants merchants_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.merchants
    ADD CONSTRAINT merchants_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: portofolios portofolios_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.portofolios
    ADD CONSTRAINT portofolios_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: _prisma_migrations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public._prisma_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: artikels; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.artikels ENABLE ROW LEVEL SECURITY;

--
-- Name: categories; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

--
-- Name: contents; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.contents ENABLE ROW LEVEL SECURITY;

--
-- Name: departments; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;

--
-- Name: divisions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.divisions ENABLE ROW LEVEL SECURITY;

--
-- Name: events; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;

--
-- Name: kepengurusan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.kepengurusan ENABLE ROW LEVEL SECURITY;

--
-- Name: members; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;

--
-- Name: merchants; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.merchants ENABLE ROW LEVEL SECURITY;

--
-- Name: portofolios; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.portofolios ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = '');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT ALL ON SCHEMA auth TO postgres;


--
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres;
GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO authenticated;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;


--
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT ALL ON SCHEMA storage TO postgres;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- Name: FUNCTION algorithm_sign(signables text, secret text, algorithm text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.algorithm_sign(signables text, secret text, algorithm text) FROM postgres;
GRANT ALL ON FUNCTION extensions.algorithm_sign(signables text, secret text, algorithm text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.algorithm_sign(signables text, secret text, algorithm text) TO dashboard_user;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea, text[], text[]) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.crypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.dearmor(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_bytes(integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_uuid() FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text, integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM postgres;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM postgres;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) TO dashboard_user;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_key_id(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION sign(payload json, secret text, algorithm text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.sign(payload json, secret text, algorithm text) FROM postgres;
GRANT ALL ON FUNCTION extensions.sign(payload json, secret text, algorithm text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.sign(payload json, secret text, algorithm text) TO dashboard_user;


--
-- Name: FUNCTION try_cast_double(inp text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.try_cast_double(inp text) FROM postgres;
GRANT ALL ON FUNCTION extensions.try_cast_double(inp text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.try_cast_double(inp text) TO dashboard_user;


--
-- Name: FUNCTION url_decode(data text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.url_decode(data text) FROM postgres;
GRANT ALL ON FUNCTION extensions.url_decode(data text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.url_decode(data text) TO dashboard_user;


--
-- Name: FUNCTION url_encode(data bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.url_encode(data bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.url_encode(data bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.url_encode(data bytea) TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1mc() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v4() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_nil() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_dns() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_oid() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_url() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_x500() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;


--
-- Name: FUNCTION verify(token text, secret text, algorithm text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.verify(token text, secret text, algorithm text) FROM postgres;
GRANT ALL ON FUNCTION extensions.verify(token text, secret text, algorithm text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.verify(token text, secret text, algorithm text) TO dashboard_user;


--
-- Name: FUNCTION comment_directive(comment_ text); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql.comment_directive(comment_ text) TO postgres;
GRANT ALL ON FUNCTION graphql.comment_directive(comment_ text) TO anon;
GRANT ALL ON FUNCTION graphql.comment_directive(comment_ text) TO authenticated;
GRANT ALL ON FUNCTION graphql.comment_directive(comment_ text) TO service_role;


--
-- Name: FUNCTION exception(message text); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql.exception(message text) TO postgres;
GRANT ALL ON FUNCTION graphql.exception(message text) TO anon;
GRANT ALL ON FUNCTION graphql.exception(message text) TO authenticated;
GRANT ALL ON FUNCTION graphql.exception(message text) TO service_role;


--
-- Name: FUNCTION get_schema_version(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql.get_schema_version() TO postgres;
GRANT ALL ON FUNCTION graphql.get_schema_version() TO anon;
GRANT ALL ON FUNCTION graphql.get_schema_version() TO authenticated;
GRANT ALL ON FUNCTION graphql.get_schema_version() TO service_role;


--
-- Name: FUNCTION increment_schema_version(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql.increment_schema_version() TO postgres;
GRANT ALL ON FUNCTION graphql.increment_schema_version() TO anon;
GRANT ALL ON FUNCTION graphql.increment_schema_version() TO authenticated;
GRANT ALL ON FUNCTION graphql.increment_schema_version() TO service_role;


--
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- Name: FUNCTION lo_export(oid, text); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pg_catalog.lo_export(oid, text) FROM postgres;
GRANT ALL ON FUNCTION pg_catalog.lo_export(oid, text) TO supabase_admin;


--
-- Name: FUNCTION lo_import(text); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pg_catalog.lo_import(text) FROM postgres;
GRANT ALL ON FUNCTION pg_catalog.lo_import(text) TO supabase_admin;


--
-- Name: FUNCTION lo_import(text, oid); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pg_catalog.lo_import(text, oid) FROM postgres;
GRANT ALL ON FUNCTION pg_catalog.lo_import(text, oid) TO supabase_admin;


--
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: postgres
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;


--
-- Name: FUNCTION crypto_aead_det_decrypt(message bytea, additional bytea, key_uuid uuid, nonce bytea); Type: ACL; Schema: pgsodium; Owner: pgsodium_keymaker
--

GRANT ALL ON FUNCTION pgsodium.crypto_aead_det_decrypt(message bytea, additional bytea, key_uuid uuid, nonce bytea) TO service_role;


--
-- Name: FUNCTION crypto_aead_det_encrypt(message bytea, additional bytea, key_uuid uuid, nonce bytea); Type: ACL; Schema: pgsodium; Owner: pgsodium_keymaker
--

GRANT ALL ON FUNCTION pgsodium.crypto_aead_det_encrypt(message bytea, additional bytea, key_uuid uuid, nonce bytea) TO service_role;


--
-- Name: FUNCTION crypto_aead_det_keygen(); Type: ACL; Schema: pgsodium; Owner: supabase_admin
--

GRANT ALL ON FUNCTION pgsodium.crypto_aead_det_keygen() TO service_role;


--
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO supabase_realtime_admin;


--
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO supabase_realtime_admin;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO supabase_realtime_admin;


--
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO supabase_realtime_admin;


--
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO supabase_realtime_admin;


--
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO supabase_realtime_admin;


--
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO supabase_realtime_admin;


--
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO postgres;
GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;


--
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.flow_state TO dashboard_user;


--
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.identities TO dashboard_user;


--
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.mfa_factors TO dashboard_user;


--
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.saml_providers TO dashboard_user;


--
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.schema_migrations TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.schema_migrations TO postgres;
GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sessions TO dashboard_user;


--
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sso_domains TO dashboard_user;


--
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.sso_providers TO dashboard_user;


--
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE extensions.pg_stat_statements FROM postgres;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE extensions.pg_stat_statements TO dashboard_user;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE extensions.pg_stat_statements_info FROM postgres;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE extensions.pg_stat_statements_info TO dashboard_user;


--
-- Name: SEQUENCE seq_schema_version; Type: ACL; Schema: graphql; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE graphql.seq_schema_version TO postgres;
GRANT ALL ON SEQUENCE graphql.seq_schema_version TO anon;
GRANT ALL ON SEQUENCE graphql.seq_schema_version TO authenticated;
GRANT ALL ON SEQUENCE graphql.seq_schema_version TO service_role;


--
-- Name: TABLE decrypted_key; Type: ACL; Schema: pgsodium; Owner: supabase_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE pgsodium.decrypted_key TO pgsodium_keyholder;


--
-- Name: TABLE masking_rule; Type: ACL; Schema: pgsodium; Owner: supabase_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE pgsodium.masking_rule TO pgsodium_keyholder;


--
-- Name: TABLE mask_columns; Type: ACL; Schema: pgsodium; Owner: supabase_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE pgsodium.mask_columns TO pgsodium_keyholder;


--
-- Name: TABLE _prisma_migrations; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public._prisma_migrations TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public._prisma_migrations TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public._prisma_migrations TO service_role;


--
-- Name: TABLE artikels; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.artikels TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.artikels TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.artikels TO service_role;


--
-- Name: TABLE categories; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.categories TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.categories TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.categories TO service_role;


--
-- Name: TABLE contents; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.contents TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.contents TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.contents TO service_role;


--
-- Name: TABLE departments; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.departments TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.departments TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.departments TO service_role;


--
-- Name: TABLE divisions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.divisions TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.divisions TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.divisions TO service_role;


--
-- Name: TABLE events; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.events TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.events TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.events TO service_role;


--
-- Name: TABLE kepengurusan; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.kepengurusan TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.kepengurusan TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.kepengurusan TO service_role;


--
-- Name: TABLE members; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.members TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.members TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.members TO service_role;


--
-- Name: TABLE merchants; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.merchants TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.merchants TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.merchants TO service_role;


--
-- Name: TABLE portofolios; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.portofolios TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.portofolios TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.portofolios TO service_role;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.refresh_tokens TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.refresh_tokens TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.refresh_tokens TO service_role;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.users TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.users TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.users TO service_role;


--
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE realtime.messages TO postgres;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;


--
-- Name: SEQUENCE messages_id_seq; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON SEQUENCE realtime.messages_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.messages_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.messages_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.messages_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.messages_id_seq TO service_role;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE realtime.schema_migrations TO postgres;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE realtime.schema_migrations TO dashboard_user;
GRANT SELECT ON TABLE realtime.schema_migrations TO anon;
GRANT SELECT ON TABLE realtime.schema_migrations TO authenticated;
GRANT SELECT ON TABLE realtime.schema_migrations TO service_role;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE realtime.schema_migrations TO supabase_realtime_admin;


--
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE realtime.subscription TO postgres;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE realtime.subscription TO supabase_realtime_admin;


--
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO supabase_realtime_admin;


--
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.buckets TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.buckets TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.buckets TO service_role;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.buckets TO postgres;


--
-- Name: TABLE migrations; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.migrations TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.migrations TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.migrations TO service_role;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.migrations TO postgres;


--
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.objects TO anon;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.objects TO authenticated;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.objects TO service_role;
GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.objects TO postgres;


--
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;


--
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: pgsodium; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium GRANT ALL ON SEQUENCES TO pgsodium_keyholder;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: pgsodium; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO pgsodium_keyholder;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: pgsodium_masks; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium_masks GRANT ALL ON SEQUENCES TO pgsodium_keyiduser;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: pgsodium_masks; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium_masks GRANT ALL ON FUNCTIONS TO pgsodium_keyiduser;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: pgsodium_masks; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA pgsodium_masks GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO pgsodium_keyiduser;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO service_role;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO postgres;

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

--
-- PostgreSQL database dump complete
--

